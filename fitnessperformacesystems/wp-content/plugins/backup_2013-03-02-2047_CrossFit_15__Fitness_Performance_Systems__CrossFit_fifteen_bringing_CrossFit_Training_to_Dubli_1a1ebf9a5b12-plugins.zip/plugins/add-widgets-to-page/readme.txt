=== Add Widgets to Page ===
Contributors: 
Tags: addw2p
Requires at least: 2.5
Tested up to: 3.2

Add Widgets to Page makes you able to add widget spaces like sidebar to posts and pages.

== Description ==

Add Widgets to Page makes you able to add widget spaces like sidebar to posts and pages.

To use this, place a shortcode [addw2p name="name"] to eny entries. Replace 'name' with anyword of your choice.

Note: Please only use numbers and alphabet, do not use spaces. You will not be able to delete it with this plugin. If you used a space in the name place, in the setting page, there will be a button 'Replace spaces to under score'. Using this button will change spaces to under score so you can delete it.

This will create a new area on the widget page called addw2p - name where you can drag your widgets.
If nothing shows, please refresh the widgets page.

Note: You may have to refresh several times, maybe even close the page and open it again. 

Once the new area appears below sidebar, the plugin will be working.
To change the widgets that are showing, go to Appearance -> Widgets and edit the sidebar.

To delete it, go to the setting page and check the names which you want to delete and press Delete button.

== Installation ==

1. Push the folder that you downloaded into your wp-contet/plugins folder.
2. Go to Plugin page on your WordPressSite, and activate it.

== Changelog ==
1.3.2 Change the Description. Also, Fix small bug(no more warning "has_cap was called with an argument that is deprecated since version 2.0" hopefully).

1.3.1 Fix bug. (no more �_n)

1.3 Added 'Replace spaces to under score' button.

1.2 Now, the widget space will appear at the position of the short code.
    Also checked if it works on 3.0.

1.1 added css small bugfix

1.0 
