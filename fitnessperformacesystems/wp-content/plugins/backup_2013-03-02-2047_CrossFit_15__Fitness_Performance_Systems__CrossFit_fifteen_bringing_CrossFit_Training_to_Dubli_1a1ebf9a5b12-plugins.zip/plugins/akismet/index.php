<?php
# Silence is golden.
