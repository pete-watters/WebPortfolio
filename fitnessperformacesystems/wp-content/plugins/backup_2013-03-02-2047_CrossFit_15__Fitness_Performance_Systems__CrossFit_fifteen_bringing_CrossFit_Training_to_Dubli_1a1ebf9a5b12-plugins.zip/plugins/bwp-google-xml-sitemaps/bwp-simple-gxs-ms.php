<?php
include_once(dirname(__FILE__). '/bwp-google-xml-sitemaps/bwp-simple-gxs.php');
?>