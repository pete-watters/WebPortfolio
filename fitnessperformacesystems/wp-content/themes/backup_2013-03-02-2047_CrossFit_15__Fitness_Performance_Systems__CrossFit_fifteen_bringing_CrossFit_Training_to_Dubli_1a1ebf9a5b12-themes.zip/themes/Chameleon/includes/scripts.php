<script src="<?php bloginfo('template_directory'); ?>/js/jquery.easing.1.3.js" type="text/javascript"></script>
<script src="<?php bloginfo('template_directory'); ?>/js/superfish.js" type="text/javascript"></script>
<script src="<?php bloginfo('template_directory'); ?>/js/custom.js" type="text/javascript"></script>