<br class="clear" />
<div id="footer">
	Developed by <a href="http://www.peterjwatters.com" title="Peter Watters Home">Peter Watters</a>
</div>
<?php wp_footer(); ?>	
<?php get_template_part('includes/scripts'); ?>

</body>
</html>
