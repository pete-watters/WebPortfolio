<?php include"header_about.php" ?>

      <tr>

        <td height="24"></td>

      </tr>

      <tr>

        <td><table width="932" border="0" cellspacing="0" cellpadding="0">

          <tr>

            <td width="2">&nbsp;</td>

            <td width="215" valign="top"><!-- InstanceBeginEditable name="navigation" -->

              <table width="100%" border="0" cellspacing="0" cellpadding="0" background="images/left_tab_horizntal_bg.jpg">

                <tr>

                  <td width="16" height="35"><img src="images/left_tab_top_left_cnr.jpg" width="16" height="35" /></td>

                  <td height="35" background="images/left_tab_bg.jpg"><img src="images/about.gif" width="33" height="9" /></td>

                  <td width="14" height="35"><img src="images/left_tab_top_rght_cnr.jpg" width="14" height="35" /></td>

                </tr>

                <!--tr>

                <td width="16" height="11"><img src="images/inner_pg_top_lft_cnr.jpg" width="16" height="11" align="top" /></td>

                <td height="11"><img src="images/inner_pg_tab_top_img.jpg" width="185" height="11" align="top" /></td>

                <td width="14" height="11"><img src="images/inner_pg_top_right_cnr.jpg" width="14" height="11" align="top" /></td>

              </tr-->

                <tr>

                  <td colspan="3" class="left_nav">&nbsp;</td>

                </tr>

                <tr>

                  <td colspan="3" class="left_nav"><a href="about.htm" class="topsel">Company Overview</a></td>

                </tr>

                <tr>

                  <td colspan="3" class="left_nav"><a href="management.htm">Management</a></td>

                </tr>

                <tr>

                  <td colspan="3" background="images/left_tab_horizntal_bg.jpg" class="text">&nbsp;</td>

                </tr>

                <tr>

                  <td width="16" height="20"><img src="images/left_tab_bttm_lft_cnr.jpg" width="16" height="20" /></td>

                  <td height="20"><img src="images/left_tab_bott_img.jpg" width="185" height="20" /></td>

                  <td width="14" height="20"><img src="images/left_tab_bttm_rght_cnr.jpg" width="14" height="20" /></td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" ><img src="images/company_overview.gif" width="140" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td class="text">Ocuco has developed two of the most comprehensive ranges of practice software on the market for opticians, ophthalmologists<br />

                    and optometrists today, as well as the market leading optical laboratory management software in the UK and Europe, drs<br />

      Labman. We have been supplying and supporting Windows-based optical practice and lab management systems since 1990, and<br />

      today have a complete range of products to suit every need.<br />

      <p>From F.O.C.U.S. to Acuitas we have applications that have been developed to deliver real, measurable business benefit to<br />

        practices and groups wishing to make the most of computer technology. </p>

      <strong><span style="font-size:13px; line-height:26px;">Values</span></strong><br />

      <strong>Our Clients &minus; </strong>We are committed to the concept that we can only deliver the benefits our clients need by working in<br />

      partnership with them. From product development to support, we work with our clients to ensure that the products and services<br />

      are tailored to their needs. The proof of this can be found in our commitment to the regular User Groups, which meet at<br />

      regular intervals to review our systems and services and discuss future product development.<br />

      <p><strong>Our People &ndash; </strong> Ocuco is all about people. Nowhere else will you find a group of people more dedicated to the needs of their<br />

        customers. We have created an environment that promotes ingenuity, resourcefulness, and an entrepreneurial spirit that is<br />

        exemplary.</p></td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

