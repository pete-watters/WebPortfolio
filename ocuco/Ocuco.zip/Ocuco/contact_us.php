  <?php include("header.php")?>
  
  <tr>

        <td height="24"></td>

      </tr>

      <tr>

        <td><table width="932" border="0" cellspacing="0" cellpadding="0">

          <tr>

            <td width="2">&nbsp;</td>

            <td width="215" valign="top"><!-- InstanceBeginEditable name="navigation" -->

              <table width="100%" border="0" cellspacing="0" cellpadding="0" background="images/left_tab_horizntal_bg.jpg">

                <tr>

                  <td width="16" height="35"><img src="images/left_tab_top_left_cnr.jpg" width="16" height="35" /></td>

                  <td height="35" background="images/left_tab_bg.jpg"><img src="images/download.gif" width="57" height="10" /></td>

                  <td width="14" height="35"><img src="images/left_tab_top_rght_cnr.jpg" width="14" height="35" /></td>

                </tr>

                <!--tr>

                <td width="16" height="11"><img src="images/inner_pg_top_lft_cnr.jpg" width="16" height="11" align="top" /></td>

                <td height="11"><img src="images/inner_pg_tab_top_img.jpg" width="185" height="11" align="top" /></td>

                <td width="14" height="11"><img src="images/inner_pg_top_right_cnr.jpg" width="14" height="11" align="top" /></td>

              </tr-->

                <tr>

                  <td colspan="3" class="left_nav">&nbsp;</td>

                </tr>

                <tr>

                  <td colspan="3" class="left_nav"><a href="download.contact_us" class="topsel">Contact Us</a></td>

                </tr>

               
                <tr>

                  <td colspan="3" class="text">&nbsp;</td>

                </tr>

                <tr>

                  <td colspan="3" background="images/left_tab_horizntal_bg.jpg" class="text">&nbsp;</td>

                </tr>

                <tr>

                  <td colspan="3" background="images/left_tab_horizntal_bg.jpg" class="text">&nbsp;</td>

                </tr>

                <tr>

                  <td colspan="3" background="images/left_tab_horizntal_bg.jpg" class="text">&nbsp;</td>

                </tr>

                <tr>

                  <td colspan="3" background="images/left_tab_horizntal_bg.jpg" class="text">&nbsp;</td>

                </tr>

                <tr>

                  <td width="16" height="20"><img src="images/left_tab_bttm_lft_cnr.jpg" width="16" height="20" /></td>

                  <td height="20"><img src="images/left_tab_bott_img.jpg" width="185" height="20" /></td>

                  <td width="14" height="20"><img src="images/left_tab_bttm_rght_cnr.jpg" width="14" height="20" /></td>

                </tr>

                <tr> </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">
              
              
              
              <tr>                
 <td class="text">      
              
              <p> 
              Feel free to order a demonstration of our products, we can arrange an online demonstration or answer any queries you may have.<br>
              We will contact you promptly to understand your requirements and suggest the most appropriate solution. 
              </p>
              
              
              
                  <form method="post" action="send_email.php">

<!-- DO NOT change ANY of the php sections -->
<?php
$ipi = getenv("REMOTE_ADDR");
$httprefi = getenv ("HTTP_REFERER");
$httpagenti = getenv ("HTTP_USER_AGENT");
?>

<input type="hidden" name="ip" value="<?php echo $ipi ?>" />
<input type="hidden" name="httpref" value="<?php echo $httprefi ?>" />
<input type="hidden" name="httpagent" value="<?php echo $httpagenti ?>" />


Your Name: <br />
<input type="text" name="visitor" size="35" />
<br />
Your Email:<br />
<input type="text" name="visitormail" size="35" />
<br /> <br />
<br />
Attention:<br />
<select name="attn" size="1">
<option value=" Order Demonstration ">Order Demonstration </option> 
<option value=" Sales n Billing ">Sales n Billing </option> 
<option value=" General Support ">General Support </option> 
<option value=" Technical Support ">Technical Support </option> 
<option value=" HR ">HR</option> 

</select>
<br /><br />
Mail Message:
<br />
<textarea name="notes" rows="4" cols="40"></textarea>
<br />
<input type="submit" value="Send Mail" />
<br />

</form>
              </td>
              </tr>
              
              
              
              
              
              
              
              
              
              
              
              
              </p>

          
               

                        </table></td>

                      </tr>

                  </table></td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text"> Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td height="38">&nbsp;</td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

