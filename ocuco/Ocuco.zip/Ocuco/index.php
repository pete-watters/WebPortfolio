<?php include("index_header.php")?>


<body>


 <?php include("top_navigation.php")?>
</table></td>    
  </tr>     
  
 <?php include("embed_main_logo.php"); ?>    
             
<?php include("menu_top.php"); ?>

<?php include("side_menu.php"); ?>

    
 <!--Start of main content --> 
 <tr>                
 <td height="8" colspan="3" valign="top">
 <img src="images/spacer.gif" width="1" height="8" /></td>                </tr>            </table></td>            
 <td width="29">&nbsp;</td>            
 <td width="438" valign="top">
 <table width="100%" border="0" cellspacing="0" cellpadding="0">              
 <tr>                
 <td height="21" background="images/line_bg.jpg"  valign="top" alt = "" >
 <img src="images/software_solutions.gif" width="327" height="20" alt = "Software solutions for healthcare professionals"/></td>              </tr>              
 <tr>                
 <td height="5">
 <img src="images/spacer.gif" width="1" height="5" alt = "" /></td>              </tr>              
 <tr>                
 <td class="text">          
 <p>        
 If you are an optician, or manage a chain of optical stores, an ophthalmologist or you work in a large eye clinic, optical lab or eye hospital, 
 you will need a software solution to manage patient records, appointments, clinical exams, dispensing, point of sale, stock, laboratory, or imaging and eye testing equipment.     
 </p>          
 <p>
 If so, Ocuco have a solution for your needs, whatever the size of your business.
 </p>
 </td>              
 </tr>                            
 <tr>                
 <td height="20"></td>              
 </tr>              
 
 <tr>                
 <td>
 <table width="100%" border="0" cellspacing="0" cellpadding="0">                  
 <tr>                    
 <td width="109" height="43" valign="top">
 <a HREF="contact_us.php">
 <img src="images/order_demo_img.jpg" border="0" alt = "Order a demo" ></a>
 </td>          
           
 <!-- hide add-ons
 <td width="38" height="43">&nbsp;</td>                    
 <td width="109" height="43" valign="top">
 <a href="buy_ocuco_software.html">
 <img src="images/icon_buy_software.jpg" width="105" height="40" border="0" alt = ""  /></a></td>                    -->

 <td width="40" height="43">&nbsp;</td>                    

 <td width="149" height="43" valign="top">
 <a HREF="download.php" >
 
 <img src="images/downld_brchr_img.jpg" width="148" height="43" border="0" alt = "Download a brochure"  /></a>
 </td>                  </tr>                
 </table></td>              </tr>          
     
 <tr>                
 <td height="15" valign="top">
 <img src="images/spacer.gif" width="1" height="15"  alt=""/></td>              </tr>   
            
 <tr>                
 <td height="16" background="images/products_bg.jpg" valign="top">
 <img src="images/see_ocuco_img.gif" width="78" height="9"   /></td>              
  </tr>
  
  
              <tr>
                 <td align="center" valign="middle" style="padding-top:10px;">
              <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0" width="400" height="66">
                          <param name="movie" value="http://www.ocuco.co.uk/flash/new.swf" />
                          <param name="quality" value="high" />
                          <embed src="http://www.ocuco.co.uk/flash/new.swf" quality="high" pluginspage="http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="400" height="66"></embed>
              		  </object>
             
                
                </td>
              </tr>
</table></td>          



  <td width="30">&nbsp;</td>            
  <td width="215" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">                           
   <tr>                <td>
   <table width="100%" border="0" cellspacing="0" cellpadding="0">   
                  <tr>                    
                  <td width="13" align="left" valign="top">
                  <img src="images/right_tab_top_left_cnr.jpg" alt="" width="13" height="35" /></td>                    
                  <td valign="top" background="images/right_tab_top_bg.jpg" style="padding-top:14px;" >
                  <a href="news_released_press.html"><img src="images/latest_news_img.jpg" width="31" height="9" border="0" alt = "Latest news"  /></a></td>
                                      <td width="13" align="right" valign="top">
                                      <img src="images/right_tab_top_right_cnr.jpg" alt="" width="13" height="35" /></td>                  
                 </tr>                  
                   <tr>                    
                   <td colspan="3" style="border-left:1px solid #dbdbdb; border-right:1px solid #dbdbdb;">
                   <table width="100%" border="0" cellspacing="0" cellpadding="0">                      
                   <tr>                        <td>&nbsp;</td>       
   
              
             
 
                    
  
  <tr>                        
  <td width="13">&nbsp;</td>                        
  <td class="red_text" style="line-height:18px;">Latest News</td>                      
  </tr> 
   
             
  
   <tr>                        
  <td width="13">&nbsp;</td>                        
  <td class="text" style="line-height:18px;">4th-March-2009: Vision Express extends contract with Ocuco to 2016.</td>                      
  </tr>                      
  <tr>                        
  <td colspan="2" valign="top">
  <img src="images/spacer.gif" width="1" height="5" /></td>                        </tr>                      
  
  <tr>                        
  <td>&nbsp;</td>                        
  <td align="right" class="text" style="padding-right:17px;">
  <a href="news.php">Read More</a></td>                      
  </tr> 
            
   <tr>                        
  <td width="13">&nbsp;</td>                        
  <td class="red_text" style="line-height:18px;">New for Optrafair</td>                      
  </tr> 
                
  
   <tr>                        
  <td width="13">&nbsp;</td>                        
  <td class="text" style="line-height:18px;">Ocuco will be showing new features in their two product lines, Acuitas and   Focus.</td>                      
  </tr>                      
  <tr>                        
  <td colspan="2" valign="top">
  <img src="images/spacer.gif" width="1" height="5" /></td>                        </tr>                      
  
  <tr>                        
  <td>&nbsp;</td>                        
  <td align="right" class="text" style="padding-right:17px;">
  <a href="ocuco_pdf/news_optrafair.pdf">Read More</a></td>                      
  </tr>                    
  </table></td>                    </tr>                  
  
  <tr>                    
  <td align="left" valign="bottom">
  <img src="images/right_tab_bott_lft_cnr.jpg" alt=""  width="13" height="16" /></td>                    
  <td valign="bottom"><img src="images/2.jpg" width="189" height="16" /></td>                    
  <td align="right" valign="bottom"><img src="images/right_tab_bott_right_cnr.jpg" alt="" width="13" height="16" /></td>                  
  </tr>                </table></td>              
  </tr>                            
  <tr>                
  <td height="8" valign="top">
  <img src="images/spacer.gif" width="1" height="8" />
  </td>              
  </tr>              
  <tr>                
  <td>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">                  
  <tr>                    
  <td width="13" align="left" valign="top">
  <img src="images/right_tab_top_left_cnr.jpg" alt="" width="13" height="35" /></td>                    
  <td valign="top" background="images/right_tab_top_bg.jpg" style="padding-top:14px;" ><a href="news.htm">
  <img src="images/events_img.jpg" width="37" height="9" border="0" /></a></td>                    
  <td width="13" align="right" valign="top">
  <img src="images/right_tab_top_right_cnr.jpg" alt="" width="13" height="35" /></td>                  </tr>                 
  <tr>                    
  <td colspan="3" style="border-left:1px solid #dbdbdb; border-right:1px solid #dbdbdb;">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr>                          <td>&nbsp;</td>                          
 
 <td class="red_text" style="padding-top:5px;">MIDO 2009
</td>                        </tr>                        
<tr>                          <td width="13">&nbsp;</td>                          
<td class="text" style="line-height:18px;">
Friday 06 Mar 2009 to Monday 09 Mar 2009
<br />Milan, Italy
</td>                        </tr>                        
<tr>                          

<td colspan="2" valign="top">
<img src="images/spacer.gif" width="1" height="5" /></td>                          </tr>                        
<tr>                          <td>&nbsp;</td>                          

<td align="right" class="text" style="padding-right:17px;">
<a href="http://www.mido.it" target="_blank">See More</a></td>                        
</tr>                    </table></td>                  </tr>                  



<?php include("footer.php")?>