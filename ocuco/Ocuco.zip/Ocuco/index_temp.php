<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><title>Ocuco-Home</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<SCRIPT TYPE="text/javascript">
<!--function popup(mylink, windowname)
{if (! window.focus)return true;
											var href;
if (typeof(mylink) == 'string')   
										href=mylink;
else   href=mylink.href;window.open(href, windowname, 'width=425,height=540,scrollbars=yes');
return false;}//-->
</SCRIPT>
<script type="text/javascript" src="jquery-1.2.2.pack.js"></script>
<script type="text/javascript" src="ddaccordion.js"></script>
<script type="text/javascript" src="js/image-slideshow.js"></script>

<script type="text/javascript">


ddaccordion.init({

	headerclass: "expandable", //Shared CSS class name of headers group that are expandable

	contentclass: "categoryitems", //Shared CSS class name of contents group

	collapseprev: true, //Collapse previous content (so only one open at any time)? true/false 

	defaultexpanded: [1], //index of content(s) open by default [index1, index2, etc]. [] denotes no content

	animatedefault: true, //Should contents open by default be animated into view?

	persiststate: true, //persist state of opened contents within browser session?

	toggleclass: ["", "openheader"], //Two CSS classes to be applied to the header when it's collapsed and expanded, respectively ["class1", "class2"]

	togglehtml: ["prefix", "", ""], //Additional HTML added to the header when it's collapsed and expanded, respectively  ["position", "html1", "html2"] (see docs)

	animatespeed: "normal" //speed of animation: "fast", "normal", or "slow"

})

function MM_openBrWindow(theURL,winName,features) { //v2.0

  window.open(theURL,winName,features);

}

</script>

<script src="prototype.js" type="text/javascript"></script>
<script src="effects.js" type="text/javascript"></script>
<script src="newsticker.js" type="text/javascript"></script>
<link href="newsticker.css" type="text/css" rel="stylesheet" />
<style type="text/css">
.arrowlistmenu{width: 180px; margin-left:15px;margin-top:14px;padding:0px;}

.arrowlistmenu .menuheader{ /*CSS class for menu headers in general (expanding or not!)*/font: normal 11px Tahoma;color: #000000;background-image:url(images/accordian_menu_item_bg.jpg);background-repeat:repeat-y;border-top:1px solid #e0dfdf;/*border-bottom:1px solid #e0dfdf;*/width:185px;height:25px;line-height:25px;text-indent:10px;margin:0px;padding:0px;cursor:pointer;}.arrowlistmenu .openheader{ /*CSS class to apply to expandable header when it's expanded*/background-image:url(images/accordian_menu_item_bg.jpg);background-repeat:repeat-y;border-top:1px solid #e0dfdf;/*border-bottom:1px solid #e0dfdf;*/width:185px;}.arrowlistmenu ul{ /*CSS for UL of each sub menu*/list-style-type: none;margin: 0;padding: 0;/*background-image:url(ul_bg.gif);width:185px;background-repeat:repeat-y;*/}.arrowlistmenu ul li{font: normal 11px Tahoma;color: #000000;margin:0px;}.arrowlistmenu ul li a{color: #000000;padding-left: 25px; /*link text is indented 19px*/text-decoration: none;font-family:Tahoma;font-size: 11px;}/*.arrowlistmenu ul li a:visited{color: #A70303;}*/.arrowlistmenu ul li a:hover{ /*hover state CSS*/color: #e1261d;}#dhtmlgoodies_slideshow{		width:438px;	/* Total width of slideshow */}			#galleryContainer{		width:438px;		/* Height of the images + 2 */		position:relative;		overflow:hidden;		margin-top:16px;		height:81px;					}	#arrow_left{	position:absolute;	z-index:10;	background-color: #FFF;	left:0px;	height:49px;	padding-top:23px;	padding-right:10px;	width:10px;	}	#arrow_right{	position:absolute;	right:0px;	z-index:10;	background-color: #FFF;		padding:1px;		height:49px;	padding-top:23px;	padding-left:10px;	width:10px;		}	*html #arrow_left{	position:absolute;	z-index:10;	background-color: #FFF;	left:0px;	height:49px;	padding-top:23px;	padding-right:10px;	width:10px;	}		*html #arrow_right{	position:absolute;	right:0px;	z-index:10;	background-color: #FFF;		padding:1px;		height:49px;	padding-top:21px;	padding-left:10px;	width:10px;	}		#theImages{	position:absolute;	height:73px;		width:100000px;	}	#theImages #slideEnd{		float:left;	}	#theImages img{		float:left;		padding:1px;		padding-left:30px;		padding-right:35px;		background-image:url(images/bar.jpg);		height:70px;		background-repeat:no-repeat;		background-position:right;		cursor:pointer;		border:0px;	}	#waitMessage{		display:none;		position:absolute;		left:200px;		top:150px;		background-color:#FFF;		border:3px double #000;		padding:4px;		color:#555;		font-size:0.9em;		font-family:arial;		}		#theImages .imageCaption{		display:none;	}</style>

<script src="Scripts/AC_RunActiveContent.js" type="text/javascript"></script>

</head>
<body>

<table width="100%" border="0" cellspacing="0" cellpadding="0">  
<tr>    <td class="top_section" valign="top">
<table width="932" border="0" align="center" cellpadding="0" cellspacing="0">     
 <tr>        <td height="33" valign="top">
 <table width="100%"  border="0" cellspacing="0" cellpadding="0">          
 <tr>            
 <td height="32" class="top_links">
 <a href="index.htm">Home</a> |  <a href="contact_us.htm">Contact</a> </td>          
</tr>        
</table></td>    
  </tr>     
  
   <tr>        
   <td><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" width="932" height="193">          
  <param name="movie" value="flash/option1_15.swf" />         
   <param name="quality" value="high" />        
     <embed src="flash/option1_15.swf" width="932" height="193" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash"></embed>  
           </object></td>      
           </tr>      
<tr>        
<?php include("menu_top.php"); ?>
</tr>        
</table>         


</div>       
</td>      
</tr>      

<?php include("side_menu.php"); ?>
 
 <tr>                
 <td height="8" colspan="3" valign="top">
 <img src="images/spacer.gif" width="1" height="8" /></td>                </tr>            </table></td>            
 <td width="29">&nbsp;</td>            
 <td width="438" valign="top">
 <table width="100%" border="0" cellspacing="0" cellpadding="0">              
 <tr>                
 <td height="21" background="images/line_bg.jpg"  valign="top">
 <img src="images/software_solutions.gif" width="327" height="20" /></td>              </tr>              
 <tr>                
 <td height="5"><img src="images/spacer.gif" width="1" height="5" /></td>              </tr>              
 <tr>                
 <td class="text">                  
 If you are an optician, or manage a chain of optical stores, an ophthalmologist or you work in a large eye clinic, optical lab or eye hospital, 
 you will need a software solution to manage patient records, appointments, clinical exams, dispensing, point of sale, stock, laboratory, or imaging and eye testing equipment.<br>                  
 If so, Ocuco have a solution for your needs, whatever the size your business.</td>              
 </tr>                            
 <tr>                
 <td height="20"></td>              
 </tr>              
 <tr>                
 <td>
 <table width="100%" border="0" cellspacing="0" cellpadding="0">                  
 <tr>                    
 <td width="109" height="43" valign="top">
 <a HREF="order_demo.htm">
 <img src="images/order_demo_img.jpg" border="0"></a>
 </td>                    
 <td width="38" height="43">&nbsp;</td>                    
 

 
 <td width="40" height="43">&nbsp;</td>                    
 <td width="149" height="43" valign="top">
 <a HREF="download.htm" ><img src="images/downld_brchr_img.jpg" width="148" height="43" border="0" /></a>
 </td>                  </tr>                </table></td>              </tr>              
 <tr>                
 <td height="15" valign="top">
 <img src="images/spacer.gif" width="1" height="15" /></td>              </tr>              
 <tr>                
 <td height="16" background="images/products_bg.jpg" valign="top"><img src="images/see_ocuco_img.gif" width="78" height="9"  /></td>              
  </tr>
  
  
              <tr>
                <td align="center" valign="middle" style="padding-top:10px;">
                		<div id="newsticker">
                        	<ul>
                            <li><img src="images/banner11.gif" width="400" height="66" /></li>
                            <li><img src="images/banner2.gif" /></li>
                            </ul>
                            
                            
                        </div>
                </td>
              </tr>
</table></td>          



  <td width="30">&nbsp;</td>            
  <td width="215" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">                           
   <tr>                <td>
   <table width="100%" border="0" cellspacing="0" cellpadding="0">   
                  <tr>                    
                  <td width="13" align="left" valign="top">
                  <img src="images/right_tab_top_left_cnr.jpg" alt="" width="13" height="35" /></td>                    
                  <td valign="top" background="images/right_tab_top_bg.jpg" style="padding-top:14px;" >
                  <a href="news_released_press.html"><img src="images/latest_news_img.jpg" width="31" height="9" border="0" /></a></td>
                                      <td width="13" align="right" valign="top">
                                      <img src="images/right_tab_top_right_cnr.jpg" alt="" width="13" height="35" /></td>                  
                 </tr>                  
                   <tr>                    
                   <td colspan="3" style="border-left:1px solid #dbdbdb; border-right:1px solid #dbdbdb;">
                   <table width="100%" border="0" cellspacing="0" cellpadding="0">                      
                   <tr>                        <td>&nbsp;</td>                        
  <td class="red_text" style="padding-top:10px;">New for Optrafair</td>                      
  </tr>                      <tr>                        
  <td width="13">&nbsp;</td>                        
  <td class="text" style="line-height:18px;">Ocuco will be showing new features in their two product lines, Acuitas and   Focus.</td>                      
  </tr>                      
  <tr>                        
  <td colspan="2" valign="top"><img src="images/spacer.gif" width="1" height="5" /></td>                        </tr>                      
  <tr>                        
  <td>&nbsp;</td>                        
  <td align="right" class="text" style="padding-right:13px;">
  <a href="ocuco_pdf/news_optrafair.pdf">Read More</a></td>                      
  </tr>                    
  </table></td>                    </tr>                  
  
  <tr>                    
  <td align="left" valign="bottom">
  <img src="images/right_tab_bott_lft_cnr.jpg" alt="" width="13" height="16" /></td>                    
  <td valign="bottom"><img src="images/2.jpg" width="189" height="16" /></td>                    
  <td align="right" valign="bottom"><img src="images/right_tab_bott_right_cnr.jpg" alt="" width="13" height="16" /></td>                  
  </tr>                </table></td>              
  </tr>                            
  <tr>                <td height="8" valign="top">
  <img src="images/spacer.gif" width="1" height="8" />
  </td>              
  </tr>              
  <tr>                
  <td>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">                  
  <tr>                    
  <td width="13" align="left" valign="top">
  <img src="images/right_tab_top_left_cnr.jpg" alt="" width="13" height="35" /></td>                    
  <td valign="top" background="images/right_tab_top_bg.jpg" style="padding-top:14px;" ><a href="news.htm">
  <img src="images/events_img.jpg" width="37" height="9" border="0" /></a></td>                    
  <td width="13" align="right" valign="top">
  <img src="images/right_tab_top_right_cnr.jpg" alt="" width="13" height="35" /></td>                  </tr>                 
  <tr>                    
  <td colspan="3" style="border-left:1px solid #dbdbdb; border-right:1px solid #dbdbdb;">
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
                          <tr>                          <td>&nbsp;</td>                          
 
 <td class="red_text" style="padding-top:5px;">MIDO 2009
</td>                        </tr>                        
<tr>                          <td width="13">&nbsp;</td>                          
<td class="text" style="line-height:18px;">
Friday 06 Mar 2009 to Monday 09 Mar 2009
<br />Milan, Italy
</td>                        </tr>                        
<tr>                          

<td colspan="2" valign="top">
<img src="images/spacer.gif" width="1" height="5" /></td>                          </tr>                        
<tr>                          <td>&nbsp;</td>                          

<td align="right" class="text" style="padding-right:13px;">
<a href="http://www.mido.it" target="_blank">See More</a></td>                        
</tr>                    </table></td>                  </tr>                  

<tr>                    
<td align="left" valign="bottom">
<img src="images/right_tab_bott_lft_cnr.jpg" alt="" width="13" height="16" /></td>                    
<td valign="bottom"><img src="images/2.jpg" width="189" height="16" /></td>                    
<td align="right" valign="bottom"><img src="images/right_tab_bott_right_cnr.jpg" alt="" width="13" height="16" /></td>
</tr>
</table>
</td>
</tr>

<tr>
<td>&nbsp;</td>              
</tr>                                                                                                                                          
</table></td>            
<td width="3">&nbsp;</td>          </tr>        </table></td>      
</tr>                      </table></td>  </tr>  
<tr>    
<td height="38" class="footer_bg">
<table width="100%" border="0" cellspacing="0" cellpadding="0">      
<tr>        
<td height="38" class="footer_bg">
<table width="932" border="0" align="center" cellpadding="0" cellspacing="0">            
<tr>              
<td><table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>                    
<td width="13" height="38" align="left" valign="top">
<img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>                    
<td width="906" background="images/footer_tab_bg.jpg" valign="middle">
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">                      
<tr>                        
<td width="524" height="38" valign="middle" class="footer_text"> 
Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>                        
<td width="382" valign="middle" class="footer_right_text" >
Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>                      
</tr>                    </table></td>                    
<td width="13">
<img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>                  </tr>              </table></td>            </tr>        </table></td>      </tr>      <tr>        <td>&nbsp;</td>      </tr>          </table></td>  </tr></table></body></html>