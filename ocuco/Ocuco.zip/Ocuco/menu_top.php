<tr>        
<td height="33" valign="top">        

<div class="navigation">        
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="33px">          

<tr class="bttn_bg" valign="top">            
       

    


<td   width="107px" valign="top">
           <div class="products">
           <a href="products.php">Products</a>
          </div>
</td>            
     
<td  width="107px" valign="top">
			<div class="downld">
			<a href="download.php">Download</a></div>
</td>            

<td width="107px" valign="top">
<div class="news">
<a href="news.php">News</a></div>
</td>         


<td  width="107px" valign="top">
<div class="partners">
<a href="partners.php">Partners</a></div>
</td>            

  <td width="97px">
  <div class="support"><a href="support.php">Support</a></div></td>
  
  
<td  width="107px" valign="top">
			<div class="about">
			<a href="about.php">About</a>
</div>
</td>     

          
<td  width="107px" valign="top">
			 <a HREF="contact_us.php">
 <img src="images/order_demo_img.jpg" border="0" alt = "Order a demo" ></a>
</td> 


<td  width="107px" valign="top">
			<a HREF="download.php" >
 
 <img src="images/downld_brchr_img.jpg" width="148" height="43" border="0" alt = "Download a brochure"  /></a>
</td>
 
<td width="100px">&nbsp;</td>            

<td width="64px" valign="top">
<img src="images/top_link_img.jpg" width="64" height="33" />
</td>
</tr>        
</table>         


</div>       
</td>      
</tr>      