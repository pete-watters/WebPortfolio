<?php include("pro_header.php")?>
        <td height="24"></td>
      </tr>
      <tr>
        <td><table width="932" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="2">&nbsp;</td>
            <td width="215" valign="top"><!-- InstanceBeginEditable name="navigation" -->
              <table width="100%" border="0" cellspacing="0" cellpadding="0" background="images/left_tab_horizntal_bg.jpg">
                <tr>
                  <td width="16" height="35"><img src="images/left_tab_top_left_cnr.jpg" width="16" height="35" /></td>
                  <td height="35" background="images/left_tab_bg.jpg"><img src="images/news.gif" width="31" height="9" /></td>
                  <td width="14" height="35"><img src="images/left_tab_top_rght_cnr.jpg" width="14" height="35" /></td>
                </tr>
                <!--tr>
                <td width="16" height="11"><img src="images/inner_pg_top_lft_cnr.jpg" width="16" height="11" align="top" /></td>
                <td height="11"><img src="images/inner_pg_tab_top_img.jpg" width="185" height="11" align="top" /></td>
                <td width="14" height="11"><img src="images/inner_pg_top_right_cnr.jpg" width="14" height="11" align="top" /></td>
              </tr-->
                <tr>
                  <td colspan="3" class="left_nav">&nbsp;</td>
                </tr>
                <tr>
                  <td colspan="3" class="left_nav"><a href="#events" class="topsel">Events Calendar </a></td>
                </tr>
                <tr>
                  <td colspan="3" class="left_nav"><a href="news_released_press.php">Press Releases</a></td>
                </tr>
<!--
                <tr>
                  <td colspan="3" class="left_nav"><a href="news_published_press.php">Published Press</a></td>
                </tr>
                <tr>
                  <td colspan="3" class="left_nav"><a href="news_newsletters.php">Newsletters</a></td>
                </tr>
-->
                <tr>
                  <td colspan="3" background="images/left_tab_horizntal_bg.jpg" class="text">&nbsp;</td>
                </tr>
                <tr>
                  <td width="16" height="20"><img src="images/left_tab_bttm_lft_cnr.jpg" width="16" height="20" /></td>
                  <td height="20"><img src="images/left_tab_bott_img.jpg" width="185" height="20" /></td>
                  <td width="14" height="20"><img src="images/left_tab_bttm_rght_cnr.jpg" width="14" height="20" /></td>
                </tr>
              </table>
            <!-- InstanceEndEditable --></td>
            <td width="30">&nbsp;</td>
            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->
              <table width="685" border="0" cellspacing="0" cellpadding="0">
              
              
              
              
              
              <tr>
                  <td height="21" background="images/line_bg.jpg" ><img src="images/news.gif" width="40" height="15" /></td>
                </tr>
                <tr>
                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>
                </tr>
                <tr>
                  <td class="text"> 4th-March-2009: Vision Express extends contract with Ocuco to 2016.
<p>
Vision Express and Ocuco have signed a five year extension to their software and support contract. Ocuco's software, Acuitas Enterprise, was first installed across their 200 store estate in 2005 with a commitment to 2010. Since then VE has grown to over 300 stores, including 75 Batemans stores acquired last year. A key tool in the acquisition's integration, Acuitas was rolled out to them in four weeks last June.</p>

<p>
Bryan Magrath, CEO of Vision Express commented "To ensure VE gets the best product and best value for money, we constantly benchmark against market. We have performed an extensive assessment of the available PMS suppliers in the industry and we are convinced that Ocuco is the best choice. There is no greater show of faith than to extend our relationship to 2016."</p>



</td>
</tr>

 <tr>
 <td align="center" valign="middle" style="padding-top:10px;">
  <p>
 <img src="images/leo.jpg" width="300" height="200" />
  </p>
 
</td>
</tr>

 
 <tr>
                  <td class="text"> 
<p>
<b>Leo MacCanna</b>, Chief Executive Officer for Ocuco said "We invested a lot in R&D to keep our customers and we are committed to keeping our product on the leading edge into the future. We look forward to renewing again in 2016.'
</p>

<p>
Acuitas is an enterprise retail system specifically developed for the optical market. It can cover the full patient journey out of the box without the need for the cost and delay of the extensive bespoke development required when implementing generic EPoS systems such as SAP retail, PCMS and Win/DSS. A new basic EPoS-only version is now available priced to compete directly against these generic EPoS systems, but with the option to add practice management, optometry, clinical and manufacturing modules.
</p>
<p>
The product is now in use in the UK and Spain, with localized versions for the French and Italian markets due to be released by end of June 2009. The system caters for the various optometry models in Europe and the Americas.
</p>
<p>
Founded in 1993, Ocuco is the largest optical retail software company outside the US with $10m in revenues and 100 staff. It is on the Deloitte European fast 500 list, with installations in most countries across the globe. Ocuco has offices in Ireland, UK, France, Italy, Spain, Australia and the USA. The company will be exhibiting at Hall 11 Stand T-02 at MIDO.
 </p>





</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
              
                <tr>
                  <td height="21" background="images/line_bg.jpg" >
                  <a name="events"><img src="images/events_calender.gif" width="110" height="20" /></a>
                  </td>
                </tr>
                <tr>
                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>
                </tr>
                <tr>
                  <td class="text"> If you are organising an event and would like Ocuco to attend, please <a href="contact_us.php">contact Ocuco </a></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td class="text"><strong>OPTIFERIA EXPO OPTICA </strong><br />
				  Sunday 10 Aug 2008 to Wednesday 13 Aug 2008 <br />
				
                   Buenos Aires , Argentina <br />
					<!--a href="http://www.link.001">http://www.link.001</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>MSOO </strong> <br />Monday 01 Sep 2008 to Friday 05 Sep 2008 <br />                   
                    Moscow, Russia <br />
                    <!--a href="http://www.link.002">http://www.link.002</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>CRIO</strong><br />
                    Saturday 13 Sep 2008 to Monday 15 Sep 2008 <br />
                    Dortmund, Germany <br />
                    <!--a href="http://www.link.003">http://www.link.003</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>21st International Optics Fair - China (Beijing)</strong><br />
                    Friday 26 Sep 2008 to Monday 29 Sep 2008 <br />
                    China International Exhibition Centre, Beijing, P.R. China <br />
                    <!--a href="http://www.link.004">http://www.link.004</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>ABDO Conference and Exhibition, Manchester </strong><br />
                    Saturday 27 Sep 2008 to Tuesday 30 Sep 2008 <br />
                    Manchester <br />
                    <a href="http://www.abdo.co.uk">http://www.abdo.co.uk</a></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>IOFT</strong><br />
                    Wednesday 01 Oct 2008 to Saturday 04 Oct 2008 <br />
                    Tokyo, Japan <br />
                    <!--a href="http://www.link.005">http://www.link.005</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>International Vision Expo West, Las Vegas</strong><br />
                    Thursday 02 Oct 2008 to Monday 06 Oct 2008 <br />
                    Sands Expo Centre, Las Vegas, USA <br />
                    <!--a href="http://www.link.006">http://www.link.006</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>ICLS Seminar 2008 - Annual Seminar &amp; Trade Show </strong><br />
                    Sunday 05 Oct 2008 to Monday 06 Oct 2008 <br />
                    Plaza Hotel, Dublin <br />
                    <!--a href="http://www.link.007">http://www.link.007</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>EFCLIN CONGRESS, Glasgow </strong><br />
                    Thursday 09 Oct 2008 to Sunday 12 Oct 2008 <br />
                    Glasgow - Thistle Hotel <br />
                    <!--a href="http://www.link.008">http://www.link.008</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>TIOF </strong><br />
                    Friday 10 Oct 2008 to Monday 13 Oct 2008 <br />
                    Thessaloniki,Greece <br />
                    <!--a href="http://www.link.009">http://www.link.009</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>Optical World - 9th Int Symposium for the Optical Industry - Paris </strong><br />
                    Thursday 30 Oct 2008 to Friday 31 Oct 2008 <br />
                    Paris, France <br />
                    <!--a href="http://www.link.010">http://www.link.010</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>SILMO, Paris</strong><br />
                    Thursday 30 Oct 2008 to Monday 03 Nov 2008 <br />
                    Porte de Versailles, Paris, France <br />
                    <a href="http://www.silmo.fr">http://www.silmo.fr</a></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>Hong Kong Optical Fair</strong><br />
                    Thursday 06 Nov 2008 to Sunday 09 Nov 2008 <br />
                    Hong Kong <br />
                    <!--a href="http://www.link.011">http://www.link.011</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>OLA - Nashville</strong><br />
                    Thursday 06 Nov 2008 to Sunday 09 Nov 2008 <br />
                    Galord Opryland Hotel, Nashville <br />
                    <!--a href="http://www.link.012">http://www.link.012</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>VISION CANADA</strong><br />
                    Friday 07 Nov 2008 to Monday 10 Nov 2008 <br />
                    Kelowna, British Columbia <br />
                    <!--a href="http://www.link.013">http://www.link.013</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>Ocuco 2008 User Group Meeting - Portugal</strong><br />
                    Sunday 09 Nov 2008 to Wednesday 12 Nov 2008 <br />
                    Vilamoura, Portugal <br />
                    <a href="http://www.ocuco.com/usergroup">http://www.ocuco.com/usergroup</a></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>SP &amp; AS - ABDO Area 2 Ocuco Talk </strong><br />
                    Wednesday 12 Nov 2008 to Thursday 13 Nov 2008 <br />
                    Central Leeds - Asda's Headquarters <br />
                    <!--a href="http://www.link.014">http://www.link.014</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>OPTICS SALON</strong><br />
                    Friday 28 Nov 2008 to Monday 01 Dec 2008 <br />
                    Kiev, Ukraine <br />
                    <!--a href="http://www.link.015">http://www.link.015</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>VISIONOPTICS </strong><br />
                    Monday 01 Dec 2008 to Tuesday 02 Dec 2008 <br />
                    New Delhi, India <br />
                    <!--a href="http://www.link.016">http://www.link.016</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>Eyecare 3000</strong><br />
                    Sunday 18 Jan 2009 to Tuesday 20 Jan 2009 <br />
                    Glasgow <br />
                    <a href="http://www.eyecare3000.co.uk">http://www.eyecare3000.co.uk</a></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>Opti 09</strong><br />
                    Friday 23 Jan 2009 to Monday 26 Jan 2009 <br />
                    New Munich Trade Fair Centre <br />
                    <!--a href="http://www.link.017">http://www.link.017</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>VISION-X DUBAI 2009</strong><br />
                    Monday 02 Feb 2009 to Tuesday 03 Feb 2009 <br />
                    Date in Feb but not decided yet <br />
                    <!--a href="http://www.link.018">http://www.link.018</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>SIOF </strong><br />
                    Wednesday 11 Feb 2009 to Sunday 15 Feb 2009 <br />
                    Shanghai/China - Shanghair Everbright Convention &amp; Exhibition Centre <br />
                    <!--a href="http://www.link.019">http://www.link.019</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>OPTIMED - Tunis - Been cancelled/postponed/changed </strong><br />
                    Monday 02 Mar 2009 to Tuesday 03 Mar 2009 <br />
                    Tunisia <br />
                    <!--a href="http://www.link.020">http://www.link.020</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>ROMOPTIK - Been cancelled/Postponed/changed </strong><br />
                    Monday 02 Mar 2009 to Tuesday 03 Mar 2009 <br />
                    Bucharest, Romania <br />
                    <!--a href="http://www.link.021">http://www.link.021</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>SNOL - Been Cancelled, postponed/changed </strong><br />
                    Monday 02 Mar 2009 to Tuesday 03 Mar 2009 <br />
                    Casablanca, Morocco <br />
                    <!--a href="http://www.link.022">http://www.link.022</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>SECO International 2009 - Georgia</strong><br />
                    Wednesday 04 Mar 2009 to Monday 09 Mar 2009 <br />
                    Georgia World Congress Centre, Atlanta, Georgia <br />
                    <!--a href="http://www.link.023">http://www.link.023</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>OPTIK ISTANBUL 2009 </strong><br />
                    Thursday 05 Mar 2009 to Monday 09 Mar 2009 <br />
                    <!--a href="http://www.link.024">http://www.link.024</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>MIDO 2009 </strong><br />
                    Friday 06 Mar 2009 to Tuesday 10 Mar 2009 <br />
                    Milan, Italy <br />
                    <a href="http://www.mido.it">http://www.mido.it</a></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>MS00 - 2009 </strong><br />
                    Tuesday 10 Mar 2009 to Saturday 14 Mar 2009 <br />
                    Moscow/Russia - Expocentr, Krasnaja <br />
                    <!--a href="http://www.link.025">http://www.link.025</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>International VisionExpo East - New York </strong><br />
                    Thursday 26 Mar 2009 to Monday 30 Mar 2009 <br />
                    Jacob K Javits Convention Centre, New York <br />
                    <!--a href="http://www.link.026">http://www.link.026</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>Expooptica </strong><br />
                    Friday 27 Mar 2009 to Monday 30 Mar 2009 <br />
                    Madrid- Spain <br />
                    <!--a href="http://www.link.027">http://www.link.027</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>Optrafair 2009 </strong><br />
                    Saturday 04 Apr 2009 to Tuesday 07 Apr 2009 <br />
                    NEC Exhibition Centre, Birmingham <br />
                    <a href="http://www.optrafair.co.uk">http://www.optrafair.co.uk</a></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>Wenzhou International Optics Fair </strong><br />
                    Wednesday 01 Jul 2009 to Thursday 02 Jul 2009 <br />
                    Wenzhou/China <br />
                    <!--a href="http://www.link.028">http://www.link.028</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>CIOF </strong><br />
                    Tuesday 01 Sep 2009 to Wednesday 02 Sep 2009 <br />
                    Beijing/China <br />
                    <!--a href="http://www.link.029">http://www.link.029</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>IOFTTokyo/Japan </strong><br />
                    Thursday 01 Oct 2009 to Friday 02 Oct 2009 <br />
                    <!--a href="http://www.link.030">http://www.link.030</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>Vision Expo West </strong><br />
                    Thursday 01 Oct 2009 to Sunday 04 Oct 2009 <br />
                    Las Vagas, USA <br />
                    <!--a href="http://www.link.031">http://www.link.031</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>Vision Canada </strong><br />
                    Friday 13 Nov 2009 to Monday 16 Nov 2009 <br />
                    Calgary, Alberta <br />
                    <!--a href="http://www.link.032">http://www.link.032</a--></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/strip.gif" width="110" height="1" /></td>
                </tr>
                <tr>
                  <td valign="top"><img src="images/spacer.gif" width="1" height="10" /></td>
                </tr>
                <tr>
                  <td class="text"><strong>Optical Middle East</strong><br />
                    Monday 07 Dec 2009 to Thursday 10 Dec 2009 <br />
                    Abu Dhabi National Exhibition Centre <br />
                    <!--a href="http://www.link.033">http://www.link.033</a--></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
              </table>
            <!-- InstanceEndEditable --></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      
      
      
      
    </table></td>
  </tr>
  <tr>
    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>
                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td width="524" height="38" valign="middle" class="footer_text"> Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>
                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>
                      </tr>
                    </table></td>
                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>
                  </tr>
              </table></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table>

</body>
<!-- InstanceEnd --></html>
