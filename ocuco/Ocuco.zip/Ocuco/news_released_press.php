<?php include("header.php")?>
      <tr>
        <td height="24"></td>
      </tr>
      <tr>
        <td><table width="932" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="2">&nbsp;</td>
            <td width="215" valign="top"><!-- InstanceBeginEditable name="navigation" -->
              <table width="100%" border="0" cellspacing="0" cellpadding="0" background="images/left_tab_horizntal_bg.jpg">
                <tr>
                  <td width="16" height="35"><img src="images/left_tab_top_left_cnr.jpg" width="16" height="35" /></td>
                  <td height="35" background="images/left_tab_bg.jpg"><img src="images/news.gif" width="31" height="9" /></td>
                  <td width="14" height="35"><img src="images/left_tab_top_rght_cnr.jpg" width="14" height="35" /></td>
                </tr>
                <!--tr>
                <td width="16" height="11"><img src="images/inner_pg_top_lft_cnr.jpg" width="16" height="11" align="top" /></td>
                <td height="11"><img src="images/inner_pg_tab_top_img.jpg" width="185" height="11" align="top" /></td>
                <td width="14" height="11"><img src="images/inner_pg_top_right_cnr.jpg" width="14" height="11" align="top" /></td>
              </tr-->
                <tr>
                  <td colspan="3" class="left_nav">&nbsp;</td>
                </tr>
                <tr>
                  <td colspan="3" class="left_nav"><a href="news.php" class="top">Events Calendar </a></td>
                </tr>
                <tr>
                  <td colspan="3" class="left_nav"><a href="news_released_press.php"  class="topsel" style="border-top:0px;">Press Releases</a></td>
                </tr>
<!--
                <tr>
                  <td colspan="3" class="left_nav"><a href="news_published_press.php">Published Press</a></td>
                </tr>
                <tr>
                  <td colspan="3" class="left_nav"><a href="news_newsletters.php">Newsletters</a></td>
                </tr>
-->
                <tr>
                  <td colspan="3" background="images/left_tab_horizntal_bg.jpg" class="text">&nbsp;</td>
                </tr>
                <tr>
                  <td width="16" height="20"><img src="images/left_tab_bttm_lft_cnr.jpg" width="16" height="20" /></td>
                  <td height="20"><img src="images/left_tab_bott_img.jpg" width="185" height="20" /></td>
                  <td width="14" height="20"><img src="images/left_tab_bttm_rght_cnr.jpg" width="14" height="20" /></td>
                </tr>
              </table>
            <!-- InstanceEndEditable --></td>
            <td width="30">&nbsp;</td>
            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->
              <table width="685" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td height="21" background="images/line_bg.jpg" ><img src="images/released_press.gif" width="101" height="20" /></td>
                </tr>
                <tr>
                  <td height="16"></td>
                </tr>
                <tr>
                  <td class="red_bullet">
				  <ul>
				  <li><a href="ocuco_pdf/word%20files%20for%20pdf/ocuco/NEWS_2008FEB09_ASPE%20Acquisition.pdf" target="_blank"><strong>Ocuco Makes First Acquisition on the Continent</strong></a> - <span class="date_text">09 February 2008</span></li>
				 <li><a href="ocuco_pdf/word%20files%20for%20pdf/ocuco/NEWS_2008JAN25_Ocuco%20Fast%20500.pdf" target="_blank"><strong>Ocuco in the Deloitte Technology Fast 500</strong></a> - <span class="date_text">25 January 2008</span></li>
				    <li><a href="ocuco_pdf/word%20files%20for%20pdf/ocuco/NEWS_2008JAN01_NewNameforOcucoRelcon.pdf" target="_blank"><strong>OcucoRelcon Changes its Name</strong></a> - <span class="date_text">01 January 2008</span></li>
					
					
					
					
					 <li><a href="ocuco_pdf/word%20files%20for%20pdf/labman/2005NOV30%20-%20Relcon%20Software%20Acquires%20DRS%20Computing.pdf" target="_blank"><strong>Relcon Software Acquires DRS Computing</strong></a> - <span class="date_text">November 2007</span></li>
					 <li><a href="ocuco_pdf/word%20files%20for%20pdf/ocuco/NEWS_2007NOV01_SAS%20Acquisition.pdf" target="_blank"><strong>OcucoRelcon Announces Acquisition of SAS</strong></a> - <span class="date_text">01 November 2007</span></li>
					  <li><a href="ocuco_pdf/word%20files%20for%20pdf/ocuco/NEWS_2007AUG30_Innovations%20Acquisition.pdf" target="_blank"><strong>Ocuco Inc buys Innovations&trade; Lab Software from Gerber Coburn</strong></a> - <span class="date_text">30 August 2007</span></li>
					   <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/2007AUG21%20-%20Universal_Lens_Catalogue.pdf" target="_blank"><strong>OcucoRelcon announce Universal Lens Catalogue</strong></a>- <span class="date_text">21 August 2007</span></li>
					    <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/2007AUG21%20-%20Pay_Per_Click.pdf" target="_blank"><strong>OcucoRelcon announces new &#8220;pay per click&#8221; pricing model</strong></a>- <span class="date_text">21 August 2007</span></li>
						 <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/2007AUG21%20-%20PatientPix.pdf" target="_blank"><strong>Enter Patient Pix by OcucoRelcon</strong></a>- <span class="date_text">21 August 2007</span></li>
						 <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/2007AUG21%20-%20OpticBox_Acquisition.pdf" target="_blank"><strong>OcucoRelcon announces Acquisition of OpticBox</strong></a>- <span class="date_text">21 August 2007</span></li>
						  <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/2007AUG21%20-%20OcucoRelcon_Eyeplan_Module.pdf" target="_blank"><strong>Press Release</strong></a>- <span class="date_text">21 August 2007</span></li>
						    <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/2007AUG21%20-%20Ocuco_Group_files_Accounts.pdf" target="_blank"><strong>Ocuco Group files accounts</strong></a>- <span class="date_text">21 August 2007</span></li>
						   <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/2007AUG21%20-%20New_Indian_Site.pdf" target="_blank"><strong>New Indian Site for OcucoRelcon</strong></a>- <span class="date_text">21 August 2007</span></li>
						     <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/2007AUG21%20-%20ASP_Model.pdf" target="_blank"><strong>OcucoRelcon announces web-based PMS offering</strong></a>- <span class="date_text">21 August 2007</span></li>
						   <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/2007AUG21%20-%20Acuitas_Remastered.pdf" target="_blank"><strong>Ocuco Relcon announces Acuitas Remastered</strong></a> - <span class="date_text">21 August 2007</span></li>
						    <li><a href="ocuco_pdf/word%20files%20for%20pdf/ocuco/NEWS_2007JUL27_OcucoGroupFinancial%20Results.pdf" target="_blank"><strong>Ocuco Group files Financial Results</strong></a> - <span class="date_text">27 July 2007</span></li>
						    <li><a href="ocuco_pdf/word%20files%20for%20pdf/labman/2008MAY28%20-%20news.pdf" target="_blank"><strong>OcucoRelcon Announces Acquisition of OpticBox</strong></a> - <span class="date_text">April 2007</span></li>
							 <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/2007JAN23%20-%20NewInstallationinJamaica.pdf" target="_blank"><strong>OcucoRelcon Rolls Out in Jamaica</strong></a>- <span class="date_text">23 January 2007</span></li>
				 <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/2007JAN10%20-%20OcucoRelconInvestInRemedy.pdf" target="_blank"><strong>OcucoRelcon Invest in Customer Support Technology</strong></a>- <span class="date_text">10 January 2007</span></li>
				 
				
				 <li><a href="ocuco_pdf/word%20files%20for%20pdf/labman/2006NOV28%20-%20Online%20Ordering.pdf" target="_blank"><strong>Ocuco-Relcon rolls out first electronic lens ordering</strong></a> - <span class="date_text">November 2006</span></li>
				   <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/2006NOV14%20-%20Hodd_Barnes_Dickins.pdf" target="_blank"><strong>Hodd barnes & dickins roll out new it system</strong></a> - <span class="date_text">14 November 2006</span></li>
				    <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/2007NOV11%20-%20UserGroupBarcelona2.pdf" target="_blank"><strong>OcucoRelcon Focus User Group Conference &ndash; Barcelona</strong></a>- <span class="date_text">11 November 2006</span></li>
					 <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/2007NOV11%20-%20Innovations.pdf" target="_blank"><strong>Gerber Coburn Sells Innovations&#8482; Lab Software to Ocuco Inc.</strong></a>- <span class="date_text">11 November 2006</span></li>
					  <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/online_ordering1.pdf" target="_blank"><strong>Ocuco-Relcon rolls out first electronic lens ordering</strong></a>- <span class="date_text">1st November 2006</span></li>
					  <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/OcucoRelcon.pdf" target="_blank"><strong>Ocuco and Relcon merge</strong></a>- <span class="date_text">15 August 2006</span></li>
				  <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/RelconTopcon.pdf" target="_blank"><strong>Topcon and Relcon unveil software interfaces</strong></a>- <span class="date_text">19 July 2006</span></li>
				  
				  <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/eyeplan.pdf" target="_blank"><strong>Relcon and Eyeplan announce working partnership</strong></a>- <span class="date_text">April 2005 </span></li>
				  <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/focususergroup5.pdf" target="_blank"><strong>Making IT Work in Practice</strong></a>- <span class="date_text">February 2005</span></li>
				 <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/HandS.pdf" target="_blank"><strong>Making IT Work in Practice</strong></a>- <span class="date_text">January 2005</span></li>
				   
				
				  <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/Rodenstock.pdf" target="_blank"><strong>Relcon and Rodenstock in Alliance</strong></a>- <span class="date_text">November 2004 </span></li>
				 <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/NewWebService.pdf" target="_blank"><strong>Exciting new Web Development Services offered by Relcon</strong></a>- <span class="date_text">May 2004</span></li>
				 <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/Leightons.pdf" target="_blank"><strong>Changing the Face of Practice Management</strong></a>- <span class="date_text">May 2004</span></li>
					  
					 <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/YellowrockRelcon.pdf" target="_blank"><strong>Relcon Software forms alliance partnership with Yellowrock Presentations</strong></a>- <span class="date_text">December 2003</span></li>
					  <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/DNSRelcon.pdf" target="_blank"><strong>Relcon Software acquires the optical software business of DNS</strong></a>- <span class="date_text">1 October 2003</span></li>
					  <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/Acquisition%20by%20Continuum.pdf" target="_blank"><strong>Continuum eyes investment in Relcon Software</strong></a>- <span class="date_text">9 June 2003</span></li>
					   <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/Nigel%20Bedford%20Joins%20Relcon.pdf" target="_blank"><strong>New Salesman for Relcon Software</strong></a>- <span class="date_text">26 May 2003 </span></li>
					 <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/FOCUS%20User%20Group%20March%202003.pdf" target="_blank"><strong>F.O.C.U.S. User Group Meeting Announced</strong></a>- <span class="date_text">17 March 2003</span></li> 
				
				  
				  
				   
				   
				    <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/Relcon%20automates%20Text%20Messaging.pdf" target="_blank"><strong>Text Messaging &ndash; The key to reducing FTAs</strong></a>- <span class="date_text">16 September 2002</span></li>
				  <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/Relcon%20Automates%20Myers%20La%20Roche%20Benchmarking.pdf" target="_blank"><strong>Accurate Benchmarking made easier for independent practices</strong></a>- <span class="date_text">26 June 2002 </span></li>
					  <li><a href="ocuco_pdf/word%20files%20for%20pdf/relcon/RelconDRS.pdf" target="_blank"><strong>Relcon Software acquires DRS Computing</strong></a></li> 
				 
				  
				  
				   
				  
					
					  
					  <!--li><a href="#">Changing the Face of Practice Management</a>- <span class="date_text">November 2003</span></li-->
					  
					  
					    
						
				  <!--li><a href="#">OcucoRelcon Announces Acquisition of OpticBox</a> - <span class="date_text">20 April 2007</span></li-->



				  </ul>
				  </td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
              </table>
            <!-- InstanceEndEditable --></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      
      
      
      
    </table></td>
  </tr>
  <tr>
    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>
                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td width="524" height="38" valign="middle" class="footer_text"> Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>
                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>
                      </tr>
                    </table></td>
                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>
                  </tr>
              </table></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table>

</body>
<!-- InstanceEnd --></html>
