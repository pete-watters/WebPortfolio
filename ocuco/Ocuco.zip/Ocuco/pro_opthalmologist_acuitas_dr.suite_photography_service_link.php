<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" ><img src="images/list_of_compatible_equipment.gif" width="206" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td><table width="684" border="0" cellspacing="0" cellpadding="0">

                    <tr>

                      <td width="234" height="24" bgcolor="#efefef" class="bold_text" style="padding-left:10px;">Equipment Type</td>

                      <td width="4" height="24">&nbsp;</td>

                      <td width="221" height="24" bgcolor="#efefef" class="bold_text" style="padding-left:10px;">Make</td>

                      <td width="4" height="24">&nbsp;</td>

                      <td width="221" height="24" bgcolor="#efefef" class="bold_text" style="padding-left:10px;">Model</td>

                    </tr>

                    <tr>

                      <td width="234"  class="text" style="padding-top:10px; padding-left:10px;"><strong>Refractor head</strong><br />(A.K.A. Phoroptor)                      </td>

                      <td width="4">&nbsp;</td>

                      <td width="221" class="text" style="padding-left:10px; padding-top:19px; ">Huvitz</td>

                      <td width="4">&nbsp;</td>

                      <td width="221" class="text"  style="padding-left:10px; padding-top:19px; ">CDR-3100</td>

                    </tr>

                    <tr>

                      <td width="234">&nbsp;</td>

                      <td width="4">&nbsp;</td>

                      <td width="221" valign="top"  class="text" style="padding-left:10px;">Nidek</td>

                      <td width="4">&nbsp;</td>

                      <td width="221" valign="top" class="text"  style="padding-left:10px;">RT-1200</td>

                    </tr>

                    <tr>

                      <td width="234">&nbsp;</td>

                      <td width="4">&nbsp;</td>

                      <td width="221" style="padding-left:10px; "  class="text">Nidek</td>

                      <td width="4">&nbsp;</td>

                      <td width="221" class="text"  style="padding-left:10px;">RT-2100</td>

                    </tr>

                    <tr>

                      <td width="234">&nbsp;</td>

                      <td width="4">&nbsp;</td>

                      <td width="221" style="padding-left:10px; " class="text">Nidek</td>

                      <td width="4">&nbsp;</td>

                      <td width="221" class="text"  style="padding-left:10px;">RT-5100</td>

                    </tr>

                    <tr>

                      <td width="234">&nbsp;</td>

                      <td width="4">&nbsp;</td>

                      <td width="221" style="padding-left:10px;" class="text">Topcon</td>

                      <td width="4">&nbsp;</td>

                      <td width="221" class="text"  style="padding-left:10px;">CV-3000</td>

                    </tr>

                    <tr>

                      <td width="234">&nbsp;</td>

                      <td width="4">&nbsp;</td>

                      <td width="221" style="padding-left:10px;" class="text">Topcon</td>

                      <td width="4">&nbsp;</td>

                      <td width="221" class="text"  style="padding-left:10px;">CV-2000</td>

                    </tr>

                    <tr>

                      <td width="234">&nbsp;</td>

                      <td width="4">&nbsp;</td>

                      <td width="221" style="padding-left:10px;" class="text">Topcon</td>

                      <td width="4">&nbsp;</td>

                      <td width="221" class="text"  style="padding-left:10px;">CV-2500</td>

                    </tr>

                    <tr>

                      <td style="border-bottom:1px solid #efefef;">&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="border-bottom:1px solid #efefef;">&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="border-bottom:1px solid #efefef;">&nbsp;</td>

                    </tr>

                    <tr>

                      <td class="bold_text" style="padding-top:12px; padding-left:10px;">Auto-Kerato-Tonometer</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px; padding-top:12px;" class="text">Nidek</td>

                      <td>&nbsp;</td>

                      <td valign="bottom" class="text"  style="padding-left:10px; padding-top:3px">RKT-7700</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Nidek</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Tonoreff II</td>

                    </tr>

                    <tr>

                      <td style="border-bottom:1px solid #efefef;">&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="border-bottom:1px solid #efefef;">&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="border-bottom:1px solid #efefef;">&nbsp;</td>

                    </tr>

                    <tr>

                      <td class="bold_text" style="padding-top:12px; padding-left:10px;">Auto-Keratometer</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px; padding-top:12px;" class="text">Grand Seiko</td>

                      <td>&nbsp;</td>

                      <td valign="bottom" class="text"  style="padding-left:10px; padding-top:3px">GR-3100K</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Huvitz</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">MRK-3100</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Nidek</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">ARK-530A</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Nidek</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">ARK-700A</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Nidek</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">ARK-2000</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Nidek</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">ARK-10000</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Nidek</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">ARK-730A</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Topcon</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">KR-7000</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Topcon</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">KR-8100</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Topcon</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">KR-7000P</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Topcon</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">KR-8100P</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Topcon</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">KR-8800</td>

                    </tr>

                    <tr>

                      <td style="border-bottom:1px solid #efefef;">&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="border-bottom:1px solid #efefef;">&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="border-bottom:1px solid #efefef;">&nbsp;</td>

                    </tr>

                    <tr>

                      <td class="bold_text" style="padding-top:12px; padding-left:10px;">Auto-Refractor</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px; padding-top:12px;" class="text">Nidek</td>

                      <td>&nbsp;</td>

                      <td width="221" valign="bottom" class="text"  style="padding-left:10px; padding-top:3px">AR-330A</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Nidek</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">AR-600A</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Nidek</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">AR-630A</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Nidek</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">AR-800</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Topcon</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">RM-A2000</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Topcon</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">RM-A2300</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Topcon</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">RM-A3000</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Topcon</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">RM-A3300</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Topcon</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">RM-A7000B</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Topcon</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">RM-8000</td>

                    </tr>

                    <tr>

                      <td style="border-bottom:1px solid #efefef;">&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="border-bottom:1px solid #efefef;">&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="border-bottom:1px solid #efefef;">&nbsp;</td>

                    </tr>

                    <tr>

                      <td width="234"  class="text" style="padding-top:10px; padding-left:10px;"><strong>Lensmeter</strong><br />

                        (A.K.A. Lens Analyzer) </td>

                      <td>&nbsp;</td>

                      <td valign="bottom" class="text" style="padding-left:10px; padding-top:12px;">Humphrey - Zeiss</td>

                      <td>&nbsp;</td>

                      <td valign="bottom" class="text"  style="padding-left:10px; padding-top:3px">360</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Huvitz</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">CLN-3100</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Grand Seiko</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">GL-7000</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Nidek</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">LM-820</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Nidek</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">LM-970</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Nidek</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">LM-990A</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Nidek</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">LM-1000P</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Nidek</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">LM-1200P</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Nidek</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">LM-500</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Takagi - Seiko</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">LM-50 Alpha</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Tomey</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">TL-3000B</td>

                    </tr>

                    <tr>

                      <td style="padding-left:10px;" class="text">(A.K.A. Focimeter)</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Topcon</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">CL-2000</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Topcon</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">CL-2500</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Topcon</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">CL-100</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Topcon</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">CL-200</td>

                    </tr>

                    <tr>

                      <td style="border-bottom:1px solid #efefef;">&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="border-bottom:1px solid #efefef;">&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="border-bottom:1px solid #efefef;">&nbsp;</td>

                    </tr>

                    <tr>

                      <td width="234"  class="text" style="padding-top:10px; padding-left:10px; font-weight: bold;">Tonometer</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Keeler</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Pulsair 3000/EasyEye</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Nidek</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">NT-2000</td>

                    </tr>

                    <tr>

                      <td width="234">&nbsp;</td>

                      <td width="4">&nbsp;</td>

                      <td width="221" style="padding-left:10px;" class="text">Nidek</td>

                      <td width="4">&nbsp;</td>

                      <td width="221" style="padding-left:10px;" class="text">NT-3000</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td width="221" style="padding-left:10px;" class="text">Nidek</td>

                      <td>&nbsp;</td>

                      <td width="221" style="padding-left:10px;" class="text">NT-4000</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td width="221" style="padding-left:10px;" class="text">Reichert</td>

                      <td>&nbsp;</td>

                      <td width="221" style="padding-left:10px;" class="text">AT-555</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td width="221" style="padding-left:10px;" class="text">Topcon</td>

                      <td>&nbsp;</td>

                      <td width="221" style="padding-left:10px;" class="text">CT-60</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td width="221" style="padding-left:10px;" class="text">Topcon</td>

                      <td>&nbsp;</td>

                      <td width="221" style="padding-left:10px;" class="text">CT-80</td>

                    </tr>

                    <tr>

                      <td style="border-bottom:1px solid #efefef;">&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="border-bottom:1px solid #efefef;">&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="border-bottom:1px solid #efefef;">&nbsp;</td>

                    </tr>

                    <tr>

                      <td  class="text" style="padding-top:10px; padding-left:10px; "><strong>Field Analyzer</strong><br />

                        (A.K.A Perimeter)</td>

                      <td>&nbsp;</td>

                      <td valign="bottom" class="text" style="padding-left:10px;">Henson</td>

                      <td>&nbsp;</td>

                      <td valign="bottom" class="text" style="padding-left:10px;">6000 Compact</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Henson</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">5000</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Humphrey - Zeiss</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">HFA-I</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Humphrey - Zeiss</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">HFA-IIi</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Humphrey - Zeiss</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">720</td>

                    </tr>

                    <tr>

                      <td>&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">Optopol</td>

                      <td>&nbsp;</td>

                      <td style="padding-left:10px;" class="text">PTS-910</td>

                    </tr>

                    <tr>

                      <td style="border-bottom:1px solid #efefef;">&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="border-bottom:1px solid #efefef;">&nbsp;</td>

                      <td>&nbsp;</td>

                      <td style="border-bottom:1px solid #efefef;">&nbsp;</td>

                    </tr>

                    <tr>

                      <td  class="text" style="padding-top:10px; padding-left:10px; font-weight: bold;">Corneal Topographer</td>

                      <td>&nbsp;</td>

                      <td valign="bottom" class="text" style="padding-left:10px;">Medmont</td>

                      <td>&nbsp;</td>

                      <td valign="bottom" class="text" style="padding-left:10px;">Medmont Studio</td>

                    </tr>

                    <tr>

                      <td width="234">&nbsp;</td>

                      <td width="4">&nbsp;</td>

                      <td width="221">&nbsp;</td>

                      <td width="4">&nbsp;</td>

                      <td width="221">&nbsp;</td>

                    </tr>

                  </table></td>

                </tr>

                

                

                

                

                <tr>

                  <td class="text" style="padding-top:7px;"> </td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

