<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" ><img src="images/manipulating_image.gif" width="146" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td height="8" class="text"> All of the image manipulation operations are performed on a duplicate image,keeping the original intact.</td>

                </tr>

                <tr>

                  <td class="red_bullet" style="padding-top:10px; ">Apply the following filter effects



 <ul><li>Bleed &ndash; Reduce the red saturation, without affecting the overall colour</li>

 <li>Bump map &ndash; Get a reverse gray scale rendering of the image,highlighting the blood vessels with an embossed<br /> 

   effect</li>

 <li>Blur &ndash; Smooth over sharp image for printing purpose</li>

 <li>Edge detect &ndash; Automatically mark & highlight edges</li>

 <li>Greyscale &ndash; Convert a colour image to gray scale</li>

 <li>Negative &ndash; Invert the colour to bring out hidden details</li>

 <li>Red &ndash; Isolate the red channel (useful for anaglyphic stereo pairing)</li>

 <li>Red free &ndash; Fully remove the red channel</li>

 <li>Sharpen &ndash; Reverse of Blur filter</li></ul></td>

                </tr>

                <tr>

                  <td class="text" style="padding-top:10px;">Enhance the Brightness, Contrast with quick access options</td>

                </tr>

                <tr>

                  <td class="text" style="padding-top:10px;">Adjust Colour &amp; Gamma using RGB, HSV &amp; HSL colour models</td>

                </tr>

                <tr>

                  <td class="text" style="padding-top:10px;">Apply the above manipulations to selected regions of the images with the following selection tools: Rectangular, Elliptical,<br /> 

                    Freehand &amp; Magic wand (auto selects all pixels with similar colour).</td>

                </tr>

                <tr>

                  <td class="text" style="padding-top:10px;">Crop a selected region of the image.</td>

                </tr>

                <tr>

                  <td class="text" style="padding-top:10px;">View tonal range of the image with multi-channel histogram.</td>

                </tr>

                <tr>

                  <td class="text" style="padding-top:10px;">Most of the manipulations performed on the image get logged in to notes, attached with individual images, for easy <br />

                    reproduction of a particular effect on other images &amp; additional information can also be manually recorded in the notes <br />

                    section.</td>

                </tr>

                <tr>

                  <td class="text" style="padding-top:10px;">Print Fundus images, in portrait or landscape format, with the black frame around the image automatically removed, to<br /> 

                    save printer ink. Also print selected regions or zoom in area, directly.</td>

                </tr>

                <tr>

                  <td height="8">&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

