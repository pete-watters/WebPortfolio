<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" ><img src="images/query_and_analysis.gif" width="137" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td class="text">Acuitas Clinical&rsquo;s query module allows the computer novice to select targeted groups of patients from the database for study<br /> 

                    or contact. Selections can be made on multiple criteria including demographic, lifestyle, refraction and/or other parameters. For<br /> 

                    example, an ophthalmology practice may want to extract of its database all the patients with astigmatism, or you could use the <br />

                    Query to send an SMS text message to patients whose appointment is tomorrow.</td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td class="red_bullet">

				  <strong>Key Features </strong>

	

				    <ul>

	<li>Select patients by multiple criteria including lifestyle, refraction, age, sex, purchase history... </li>

	<li>Graph New/Old patients </li>

	<li>Generate Age Profiles </li>

	<li>Save commonly used queries </li>

	<li>Generate letters / SMS etc., automatically </li>

	<li>Usable by computer novices </li>

	<li>SMS target patients </li>

	<li>Mail-shots logged with other customer communications</li>

</ul>	</td>

                </tr>

                <tr>

                  <td height="12"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td class="red_bullet">

				  	<strong>Key Benefits </strong>

	<ul>

			<li>Virtually eliminate no-shows and last minute rescheduling</li>

	<li>Bettter knowledge of patients base </li>

	</ul>	

	  </td>

                </tr>

                <tr>

                  <td height="12">&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

