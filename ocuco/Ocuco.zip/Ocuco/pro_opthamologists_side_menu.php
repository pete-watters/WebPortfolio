<tr>

        <td height="24"></td>

      </tr>

      <tr>

        <td><table width="932" border="0" cellspacing="0" cellpadding="0">

          <tr>

            <td width="2">&nbsp;</td>

            <td width="215" valign="top"><!-- InstanceBeginEditable name="navigation" -->

              <table width="100%" border="0" cellspacing="0" cellpadding="0" background="images/left_tab_horizntal_bg.jpg">

                <tr>

                  <td width="16" height="35"><img src="images/left_tab_top_left_cnr.jpg" width="16" height="35" /></td>

                  <td height="35" background="images/left_tab_bg.jpg"><img src="images/products_for_img.jpg" width="70" height="10" /></td>

                  <td width="14" height="35"><img src="images/left_tab_top_rght_cnr.jpg" width="14" height="35" /></td>

                </tr>

                <!--tr>

                <td width="16" height="11"><img src="images/inner_pg_top_lft_cnr.jpg" width="16" height="11" align="top" /></td>

                <td height="11"><img src="images/inner_pg_tab_top_img.jpg" width="185" height="11" align="top" /></td>

                <td width="14" height="11"><img src="images/inner_pg_top_right_cnr.jpg" width="14" height="11" align="top" /></td>

              </tr-->

                <tr>

                  <td colspan="3" class="left_nav">&nbsp;</td>

                </tr>

                <tr>

                  <td colspan="3" class="left_nav"><a href="pro_optician_overview.php" class="top">Opticians</a></td>

                </tr>
  
                
                
                
                
                <tr>

                  <td colspan="3" class="left_nav"><a href="pro_optical_labs_overview.php">Optical Labs</a></td>

                </tr>
                
                <tr>
                  <td colspan="3" class="left_nav"><a href="pro_opthalmologist_overview.php" >Ophthalmologists</a></td>

                </tr>

                <tr>

                  <td colspan="3" class="left_nav2" ><a href="pro_opthalmologist_acuites_clinical.php" class="selected" >Acuitas Clinical</a></td>

                </tr>


                <tr>

                  <td colspan="3" class="left_nav3" ><a href="pro_opthalmologist_acuites_clinical_spj.php">- Starting The Patient Journey</a></td>

                </tr>

                <tr>

                  <td colspan="3" class="left_nav3" ><a href="pro_opthalmologist_acuites_clinical_epr.php">- Electronic Patient Record</a></td>

                </tr>

                <tr>

                  <td colspan="3" class="left_nav3" ><a href="pro_opthalmologist_acuites_clinical_pre_test.php">- Pre-Test</a></td>

                </tr>

                <tr>

                  <td colspan="3" class="left_nav3" ><a href="pro_opthalmologist_acuites_clinical_ce.php">- Clinical Examinations</a></td>

                </tr>

                <tr>

                  <td colspan="3" class="left_nav3" ><a href="pro_opthalmologist_acuites_clinical_refraction.php">- Refraction</a></td>

                </tr>

                <tr>

                  <td colspan="3" class="left_nav3" ><a href="pro_opthalmologist_acuites_clinical_referral.php">- Referrals</a></td>

                </tr>

                <tr>

                  <td colspan="3" class="left_nav3" ><a href="pro_opthalmologist_acuites_clinical_bn.php">- Benefits and the NHS</a></td>

                </tr>

                <tr>

                  <td colspan="3" class="left_nav3" ><a href="pro_opthalmologist_acuites_clinical_recall.php">- Recall</a></td>

                </tr>

                <tr>

                  <td colspan="3" class="left_nav3" ><a href="pro_opthalmologist_acuites_clinical_query_analysis.php">- Query and Analysis</a></td>

                </tr>
                
                
                
                <tr>

                  <td colspan="3" class="left_nav2" ><a href="pro_opthalmologist_acuitas_dr.suite_overview.php" class="selected"> Acuitas DR Suite</a></td>

                </tr>
<tr>

                  <td colspan="3" class="left_nav3" ><a href="pro_opthalmologist_acuitas_dr.suite.php" >- Overview</a></td>

                </tr>

                <tr>

                  <td colspan="3" class="left_nav3" ><a href="pro_opthalmologist_acuitas_dr.suite - photography_service.php">- Photography Service</a></td>

                </tr>

                <tr>

                  <td colspan="3" class="left_nav3" ><a href="pro_opthalmologist_acuitas_dr.suite - grading_service.php">-  Grading Service</a></td>

                </tr>

                <tr>

                  <td colspan="3" class="left_nav3" ><a href="pro_opthalmologist_acuitas_dr.suite - follow_up_mgmnt_service.php" >-  Management Service</a></td>

                </tr>

               

                <tr>

                  <td colspan="3" class="left_nav2" ><a href="pro_opthalmologist_acuitas_imaging.php" class="selected">Acuitas Imaging </a></td>

                </tr>
   <tr>

                  <td colspan="3" class="left_nav3" ><a href="pro_opthalmologist_acuitas_imaging_icapture.php">- Image Capture</a></td>

                </tr>

                <tr>

                  <td colspan="3" class="left_nav3" ><a href="pro_opthalmologist_acuitas_imaging_iviewing.php">- Image Viewing</a></td>

                </tr>

                <tr>

                  <td colspan="3" class="left_nav3" ><a href="pro_opthalmologist_acuitas_imaging_imanipulation.php">- Image Manipulation</a></td>

                </tr>

                <tr>

                  <td colspan="3" class="left_nav3" ><a href="pro_opthalmologist_acuitas_imaging_icomparison.php">- Image Comparison</a></td>

                </tr>

                <tr>

                  <td colspan="3" class="left_nav3" ><a href="pro_opthalmologist_acuitas_imaging_ilayer.php">- Image Layers</a></td>

                </tr>
                <tr>

                  <td colspan="3" >&nbsp;</td>

                </tr>

                <tr>

                  <td width="16" height="20"><img src="images/left_tab_bttm_lft_cnr.jpg" width="16" height="20" /></td>

                  <td height="20"><img src="images/left_tab_bott_img.jpg" width="185" height="20" /></td>

                  <td width="14" height="20"><img src="images/left_tab_bttm_rght_cnr.jpg" width="14" height="20" /></td>

                </tr>

              </table>
              
              <!-- InstanceEndEditable --></td>



      

            <!-- InstanceEndEditable --></td>