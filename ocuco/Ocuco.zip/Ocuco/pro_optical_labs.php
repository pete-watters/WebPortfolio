<?php include("header.php")?>
   
<?php include("pro_optical_labs_side_menu.php")?> 

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" ><img src="images/labman.gif" width="67" height="20" align="top" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td class="text">Labman is deployed in some of the largest and most sophisticated prescription labs and<br />glazing workshops across the UK and continental Europe.                  </td>

                </tr>

                <tr>

                  <td class="text" style="padding-top:5px; padding-bottom:2px;">Labman runs a range of systems in optical labs:                  </td>

                </tr>

                <tr>

                  <td class="red_bullet" style="padding-top:10px; ">

                  <ul>

                  <li>lens design</li>

                  <li>order entry and validation</li>

                  <li>lens stock management</li>

                  <li>order of lenses from suppliers</li>

                  <li>cutting and glazing orders</li>

                  <li>dispatch</li>

                  <li>invoicing</li>

                  <li>accounts integration</li>

                  </ul>                  </td>

                </tr>

                <tr>

                  <td class="text" style="padding-top:5px;">Labman is highly configurable to the individual needs of users and, through over 15 years<br />of experience in this field, has been designed to allow you to run your laboratory with speed<br />and efficiency. is designed to be helpful and easy to use for operators with minimal<br />training. No detailed specialist knowledge is required.</td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

