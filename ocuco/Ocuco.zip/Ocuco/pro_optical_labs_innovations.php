<?php include("header.php")?>
   
 
<?php include("pro_optical_labs_innovations_side_menu.php")?> 

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" ><img src="images/innovations.gif" width="82" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td height="16" class="text">Innovations Lab Software automates prescription lens processing by providing a powerful set of functions designed to<br /> 

                    manage the process and business of lens manufacturing. Innovations is modular and can be custom configured to suit<br /> 

                    the specific operational needs and workstation arrangements of any size laboratory. Designed to run on single PC or<br /> 

                    over a network, Innovations is available in a variety of configurations. </td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

                <tr>

                  <td class="red_bullet">

				  <ul>

				  <li>Windows&reg; controls and graphics make it easy to navigate through the program. Online help icons reduce training time<br /> 

				    and boost productivity. </li>



<li>Accurate job entry and lens processing. </li> 



<li>Rapid intelligent order entry allows lab personnel to enter prescriptions exactly as written. "Smart lists" display only<br /> 

  relevant choices-minimizing the opportunity for operator error.  </li>



<li>Lens selection, surfacing and finishing calculations are preformed automatically using a comprehensive database of<br /> 

  lens properties.  </li>



<li>Innovations is compatible with most lab equipment. Printed job tickets and direct machine interfaces assure seamless<br /> 

  performance.  </li>



<li>Simple effective lab management.  Complete job histories are tracked via PC stations, bar code networks, and machine<br /> 

  requests to provide real-time job status feedback.  </li>



<li>Complete inventory control capabilities enable each lab to maintain vendor and on-hand data for lenses; automatically<br /> 

  generate, review, and transmit purchase orders; scan in or manually receive shipments and track back orders; and issue<br /> 

  shortage orders that direct material to waiting job trays.  Such built-in intelligence helps streamline lab workflow, while<br /> 

  freeing lab personnel to perform other tasks. </li>



<li>Innovations generates reports on new work orders, work in process, completed jobs,  inventory levels, purchasing<br /> 

  activity, lap use and other important lab management data.  Its comprehensive reporting capabilities allow managers<br /> 

  to analyze the business for more efficient and profitable operations. </li>



<li>Multitasking capabilities allow multiple Innovations tasks to run alongside programs such as e-mail, fax, word<br /> 

  processing and spreadsheets. This ability maximizes productivity improving overall lab efficiency. </li>

				  </ul>				  </td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

