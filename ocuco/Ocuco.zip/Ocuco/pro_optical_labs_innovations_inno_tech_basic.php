<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" ><img src="images/innovations_standard_technical_data.jpg" width="253" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td height="16" class="text"><p>Designed for surfacing labs performing calculations only</p></td>

                </tr>

                <tr>

                  <td class="red_bullet" style="padding-top:5px; ">

				  

<ul><li>Ability to receive electronic data from satellite dispensaries </li>



<li>Machine interface to only Gerber Coburn equipment </li>



<li>Upgradeable to management software (Standard)</li></ul>

				  </td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

                <tr>

                  <td class="red_bullet">

				  <strong>Software Modules:</strong>

<ul style="padding-top:10px; "><li>Job Entry</li>

<li>Lens Calculation</li>

<li>Lens Database</li>

<li>Frame Library Capability</li>

<li>Standard Machine Interfaces</li>

 <li>Gerber Coburn Machine Interfaces</li></ul> 

				  </td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

                <tr>

                   <td class="red_bullet">

				  <strong>Software Options:</strong>

<ul style="padding-top:10px; "><li>Job Tracking</li>

<li>Inventory Manager</li>

<li>Reports</li>

</ul> 

				  </td>

                </tr>

                <tr>

                  <td style="padding-top:10px; "><span class="text">Legacy Machine Interfaces: LOH, Nidek, Optronics</span><br />

                    <span class="text">Developers kit for automated order entry from other systems </span></td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

