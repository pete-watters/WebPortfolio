<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" ><img src="images/job_tracking.gif" width="87" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td height="16" class="text"><p>Job Tracking gives you the ability to monitor job status throughout your lab.</p>

                    <p><strong>

                        Job Tracking Features Include:</strong></p>

                    <p><strong>Windows&reg user interface</strong><br />

                      Graphic controls, drop-down menus and online help make for intuitive operation. Multi-tasking lets you track jobs without<br /> 

                      interrupting other programs. <br />

                      <br />

                      <strong>Tracking by Job Entry Status</strong><br />

                      The first action in job entry is to assign a job category which can be tracked. Any number of labels can be created. <br />

                      <br />

                      <strong>Multiple update methods</strong><br />

                      Job status can be updated when tray numbers are logged in at a PC station or scanned into a bar code network. Innovations<br /> 

                      also uses machine requests for data to update job status. <br />

                      <br />

                      <strong>Orders can find themselves</strong><br />

                      Jobs can be flagged and assigned a text message as well. When the order is subsequently logged into a device with the ability<br /> 

                      to display the message, it will do so. Bar code networks can be set to flash the wand light or to print a message at a central<br /> 

                      location when the job is scanned.<br />

                      <br />

                      <strong>Track critical jobs separately</strong><br />

                      Jobs considered critical can be flagged as such and will appear separately on tracking reports. </p>

                    <p><strong>Complete job history</strong><br />

                      You can view a job's complete history, along with its current status.</p></td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

