<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" ><img src="images/lens_calculations_and_processing.jpg" width="228" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td height="16" class="text">Innovations performs all surface and finish layout calculations automatically. A comprehensive database includes manufacturer<br />

                    -supplied curves, surfacing charts, and topographical maps for accurate processing of single vision, multifocal, and aspheric<br /> 

                    lenses. Lens selection can take place automatically based on prescription, frame trace, and material preference. Detailed<br /> 

                    machine settings can be printed or sent electronically to machine interfaces.

                    <p><strong>Lens Calculation and Processing features include: </strong></p>

                    <p><strong>Master lens database</strong><br />

                      This database allows automatic blank selection and inventory control by selecting appropriate lenses and displaying stock<br /> 

                      status. The data is refreshed in periodic lens updates that are included with annual service support contracts. <br />

                      <br />

                      <strong>Adaptable lens selection</strong><br />

                      Innovations provides flexible lens selection by using a three-pass selection process as it searches for the most appropriate <br />

                      stocked lens for the prescription and frame. When no lenses in a particular category are in-stock, lab-specified &quot;preferred <br />

                      alternates&quot; are chosen instead. If an appropriate blank cannot be found, Innovations displays the largest available blank<br /> 

                      and the frame trace, allowing the operator to move the lens in the frame to achieve cut-out, then automatically recalculates<br /> 

                      PD and seg height. <br />

                      <br />

                      <strong>Centralized data management</strong><br />

                      When new lenses are introduced, automatic updates to your database will be available on CD-ROM or via e-mail. Soon,<br /> 

                      updates will be available automatically over the Internet.<br />

                      <br />

                      <strong>Base curve selection</strong><br />

                      Base curve selection charts can be modified to suit lab preferences or to select a flatter base curve as is often needed<br /> 

                      for half-eye glasses. <br />

                      <br />

                      <strong>Lens Explorer format</strong><br />

                      The lens database is presented in the same way files are shown in Windows® Explorer. Access to lens data is more intuitive<br /> 

                      and settings for each category are easier to manage. <br />

                      <br />

                      <strong>Online help</strong><br />

                      Online help provides explanations of terms and procedures. <br />

                      <br />

                      <strong>Comprehensive worktickets</strong><br />

                      Innovations worktickets show settings for most equipment. The level of detail and layout can be modified to serve the needs<br /> 

                      of individual labs. <br />

                      <br />

                      <strong>Customized worktickets</strong><br />

                      The workticket designer enables customization of existing worktickets or the production of entirely new designs. The workticket<br /> 

                      browser allows you to browse on-screen all of the worktickets produced for each order. </p></td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

