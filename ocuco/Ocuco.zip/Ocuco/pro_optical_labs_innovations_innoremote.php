<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" ><img src="images/innovations_remote.jpg" width="139" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td height="16" class="text"><p>Innovations Remote is a solution that ensures the timely exchange of patient Rx, lens and accurate frame trace data<br /> 

                    between satellite locations and a central laboratory. Compatible with all standard tracers, it offers all segments within the<br /> 

                    ophthalmic lens dispensing chain - ODs, retail outlets and wholesale laboratories - a reliable way to build efficiency, speed<br /> 

                    and quality into the Rx delivery process. Each remote location must be equipped with Innovations Remote; the lab must be<br /> 

                    equipped with Innovations Edge, Basic or Standard.</p>

                      </td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

                <tr>

                  <td class="text">Innovations Remote Features</td>

                </tr>

                <tr>

                  <td class="red_bullet" style="padding-top:5px; ">

				  <ul>

				  <li>Windows&reg; controls and graphics make it easy to navigate through the program, reducing training time and boosting<br /> 

				    productivity.</li>

				  <li>Remote locations can opt to activate the modem on a per job basis, or stack jobs in a queue and transmit them all at the<br /> 

				    same time.</li>

				  <li>Orders can now be transferred using email.</li>

				  <li>Rapid, intelligent order entry allows the operator to enter prescriptions exactly as written. When prescription data is<br /> 

				    entered, smart lists display only relevant choices and correct mistakes immediately. This reduces opportunity for input errors.</li>

				  </ul>				  </td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

