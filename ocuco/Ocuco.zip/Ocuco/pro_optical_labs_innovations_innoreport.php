<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" ><img src="images/reports.jpg" width="53" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td height="16" class="text"><p>Innovations reports includes over thirty reports covering production and inventory. A simple user interface allows point-and-click<br /> 

                    selection of the report and level of detail. Reports can be viewed on-screen, printed or exported to standard file formats.</p>

                    <p><strong>

                        Reports Features include:</strong></p>

                    <p><strong>Windows&reg; user interface</strong><br />

                      Reports are chosen and configured with just a few &quot;point and click&quot; mouse or keyboard selections. Windows&reg; multitasking allows<br /> 

                      reports to be run alongside other active programs.</p>                    <p><strong>Wide selection of reports</strong><br />

                        You can select among summary, intermediate or detailed formats. Reports can be modified using the built-in report designer. </p>

                    <p><strong>Several variations cover </strong><br />

                      New Jobs; Work-In-Process; Production (shipments); Latency (elapsed time); Breakage; Remakes; Lens Inventory; Lap Usage</p>

                     </td>

                </tr>

                <tr>

                  <td class="red_bullet"><strong>New Jobs</strong>

				  <ul>

				  <li>By lab, Semi-Finished, Account, Material, Lens Type</li>

				  <li>By Semi-Finished, Account, Material, Lens Type</li>

				  </ul>

				  </td>

                </tr>

                <tr>

                  <td height="12"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td class="red_bullet"><strong>Production<br />

Lab Summary </strong>

				 <ul>

				 <li>By Lab, Semi-Finished, Account, Material, Lens Type</li>

                       <li>By Semi-Finished, Account, Material, Lens Type</li>

                       <li>By Semi-Finished, Lens Manufacturer, Material, Lens Type</li>

                       <li>By Semi-Finished, Lens Manufacturer, Material, Lens Option </li>

				 </ul> 

				  </td>

                </tr>

                <tr>

                  <td height="12"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td class="red_bullet"> <strong>Production Latency </strong>

                      <ul> <li>By Account</li>

                       <li>By Material</li>

                       <li>By Account, Material</li></ul></td>

                </tr>

                <tr>

                  <td height="12"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td class="red_bullet"><strong>Breakage </strong>

<ul><li>By Reason, Owner, Station ID</li></ul></td>

                </tr>

                <tr>

                  <td height="12"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td class="red_bullet"><strong>Remake </strong>

                      <ul><li>WIP &amp; Shipped by Reason</li>

                       <li>WIP &amp; Shipped by Account &amp; Reason</li>

                       <li>New Work Received by Reason</li>

                       <li>New Work Received, Account &amp; Reason</li></ul></td>

                </tr>

                <tr>

                  <td height="12"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td class="red_bullet"><strong>Work In Progress Status </strong>

                       <ul><li>By Current Status</li>

                       <li>By Date &amp; Time of Current Status</li>

                       <li>By Start Date &amp; Time </li>

                       <li>By Start Date &amp; Time &amp; Current Status</li>

                       <li>By Account</li>

                       <li>By Raw Listing by Account &amp; Rx Number</li>

                       <li>By Terminated Jobs-Raw Listing by Account &amp; Rx Number</li>

                       <li>By Account and Start Date &amp; Time</li>

                      <li> By Tray #</li>

                      <li> By Critical Trays Report</li></ul></td>

                </tr>

                <tr>

                  <td height="12"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td class="red_bullet">

				  <strong>Lens Item Inventory </strong>

                      <ul><li>By Lens Name</li>

                      <li>By Lens Name-On Hand</li>

                    <li>By Manufacturer</li>

                    <li> By Manufacturer-On Hand</li>

                     <li>On Hand Comparison</li></ul>

				  </td>

                </tr>

                <tr>

                  <td class="red_bullet">&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

