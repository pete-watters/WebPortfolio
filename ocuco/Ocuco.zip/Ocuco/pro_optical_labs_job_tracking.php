<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" valign="top" ><img src="images/job_tracking.gif" width="87" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="1" /></td>

                </tr>

                <tr>

                  <td class="text">This module allows you to monitor the progress of jobs received. You can find a particular job,<br />or a list of jobs for a particular customer, or search for a particular job by reference or tray number.<br />An extremely useful feature is the ability to record and display comments regarding a job.<br />This allows a history of chases and promises to be recorded and viewed on screen.<br />A report on overdue orders can be produced.

  <p>Job tracking allows the progress of jobs within the workshop to be recorded using keyboard or bar code,<br />and you may view the current location of a job.Jobs can be tracked around the laboratory by using a<br />network of bar &ndash; code readers or from a keyboard. The input will tell the system that the tray that is scanned<br />or keyed in has just entered the designated section.The order enquiry screen will show the current section<br />for the job and there is an option to view the last 16 sections that the tray has been in along with the date<br />&amp; time that the job went into the section.A common use is also for recording when jobs are sent out the<br /> laboratory for other processing such as coating.</p>                  </td>

                </tr>

                

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

