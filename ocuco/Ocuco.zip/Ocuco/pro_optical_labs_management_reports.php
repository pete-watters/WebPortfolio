<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 
            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" valign="top" ><img src="images/management_reports.gif" width="149" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td class="text">Labman provides many statistics and reports for various aspects of the operations of the lab,<br />such as Sales and Margin, by Product or Customer.The system maintains a statistical summary<br />database of the orders by customer and product category. The product categories are defined as,<br />for example, Uncut Glass Varifocals, Glazed Plastic Single Vision, Glass Coatings, etc.Under each<br />category, the number of jobs, gross, net &amp; margin are held. Reports can be run to show spend<br />by a range of customers over a period, and detailing spend by individual product category.                  </td>

                </tr>

                <tr >

                  <td class="text" style="padding-top:5px;">Here are a few examples of reports:                    </td>

                </tr>

                <tr>

                  <td class="red_bullet" style="padding-top:10px; ">

                  <ul>

                  <li>Daily jobs analysis</li>

                  <li>List of all orders on file</li>

                  <li>List of promised orders</li>

                  <li>Report on current location of all orders on file</li>

                  <li>List of overdue orders</li>

                  <li>Statistic reports</li>

                  </ul>                  </td>

                </tr>

                

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

