<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" valign="top" ><img src="images/lense_optomisation.gif" width="126" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                

                <tr >

                  <td class="red_bullet" style="padding-top:10px; "><ul> <li><strong>Aspheric lenses : </strong>Labman is designed to calculate the best-form for the latest aspheric lens<br />technology.</li>



<li><strong>Smart prism thinning on progressives : </strong> 

  Labman has been designed so that it will calculate the optimum prism thinning<br />required to produce the best balanced progressive lenses. </li> 







                  </ul></td>

                </tr>

                <tr>

                  <td height="12"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td><span class="text">Design is further optimised by the use of information specific to each make of lens<br />

                    contained in the lens database.</span></td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

