<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 
            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" valign="top" ><img src="images/obtain_shapes_and-frame_tracing.gif" width="233" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="1" /></td>

                </tr>

                

                <tr >

                  <td class="text" style="padding-bottom:3px;">Labman can be configured to accept the input of shapes from a number of different<br />sources:</td>

                </tr>

                <tr>

                  <td class="red_bullet" style="padding-top:10px; ">

                  <ul>

                  <li><strong>Digitiser : </strong> Our own unique method for inputting drawings quickly and easily.</li>

                  <li><strong>Library : </strong> You can specify a number of frequently used frame shapes, which may be<br />as large as you wish. </li>

                  <li><strong>Tracer : </strong> Shapes can be retrieved from glazing systems from suppliers such as Essilor,<br />Nidek, and WECO. </li>

                  </ul>                  </td>

                </tr>

                <tr>

                  <td class="text" style="padding-top:5px;">Labman can be linked to any frame, lens or former tracing system: you will only need<br />to trace the shape once for all processing in the laboratory.The system will work with the<br />majority of industry machines.For example, in the WECO system, PDM, the software will<br />configure itself as an edger attached to the system, retrieve the shape data as required<br />and convert it into the necessary format. The shape data is then used in the calculations.





</td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

