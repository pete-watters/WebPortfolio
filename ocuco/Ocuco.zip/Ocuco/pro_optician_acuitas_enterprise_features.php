<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" ><img src="images/main_features.jpg" width="97" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td class="text" >

				  This is only a selection of the main features.  

<p>A list of features will never be an accurate representation of what Acuitas Enterprise will be for your Group.  It&rsquo;s just the first line<br /> 

  in the new chapter of your IT retail infrastructure.</p>

To see exactly what Acuitas Enterprise could do for you, please 

<a href="#" onclick="MM_openBrWindow('contact_details_popup.htm','','scrollbars=yes,width=430,height=500')">contact Ocuco</a>.  We will analyse your requirements and determine<br /> 

a &quot; best fit &quot; for your solution.



				  </td>

                </tr>

                <tr>

                  <td >&nbsp;</td>

                </tr>

                <tr>

                  <td class="red_bullet" >

				  <ul>

				  <li>Central Control

					  <ul>

					  <li>&ndash; Stock</li>

					  <li>&ndash; Catalogues</li>

					  <li>&ndash; Recall</li>

					  <li>&ndash; Marketing</li>

					  </ul>

				  </li>

				  

				  <li>Information Transfer

				  		<ul>

						<li>&ndash; Patients</li>

						<li>&ndash; Stock</li>

						<li>&ndash; Store to Head Office</li>

						<li>&ndash; Store to Store</li>

						</ul>

				  </li>

				  

				  <li>Efficient Central Processing of

				  		<ul>

						<li>&ndash; Patient banking transactions</li>

						<li>&ndash; Patient Recall or Reminders</li>

						<li>&ndash; Contact Lens Subscriptions</li>

						<li>&ndash; Supplier Orders</li>

						<li>&ndash; Marketing material distribution</li>

						<li>&ndash; Appointments</li>

						</ul>

				  </li>

				  

				  <li>Multi-practice Patient Search</li>

				  

				  <li>Validated Dispensing

				  		<ul>

						<li>&ndash; Stock / Inventory</li>

						<li>&ndash; Catalogue</li>

						<li>&ndash; Till</li>

						</ul>

				  </li>

				  

				  <li>Contact Lens Schemes (Subscriptions)</li>

				  <li>Other Enterprise Features

				  		<ul>

						<li>&ndash; Recall</li>

						<li>&ndash; Marketing</li>

						<li>&ndash; Direct Debits Payments &ndash; banking transactions</li>

						<li>&ndash; Contact Lens Schemes</li>

						<li>&ndash; Stock and Catalogue

								<ul>

								<li>&bull; Stock Transfer</li>

								<li>&bull; Cross-practice search</li>

								<li>&bull; Head office setup</li>

								</ul>

						</li>

						<li>&ndash; Diary &ndash; centralised booking of appointments </li>

						</ul>

				  </li>

				  </ul>

				  </td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

