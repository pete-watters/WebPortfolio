<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" ><img src="images/viewing_photos.gif" width="110" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td class="red_bullet">

				  <ul>

				  <li>Fit image to screen or view in originally captured resolution</li>

				  <li>Zoom facility

				  		<ul>

						<li>&ndash;&nbsp; Zoom in by left mouse click & zoom out by right click</li>

						<li>&ndash;&nbsp; Also zoom in and out using the mouse wheel</li>

						<li>&ndash;&nbsp; Select an area zoom into it.</li>

						<li>&ndash;&nbsp; Look at the image with a floating, magnifying glass, which can be dragged all over the image.</li>

						</ul>

				  </li>

				  

				  <li>Rotate image, to right or left by 90° or y 180° or to a required angle.</li>

				  <li>Flip image vertically or horizontally</li>

				  </ul>				  </td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

                <tr>

                  <td><img src="images/il_3.jpg" width="395" height="286" />

                    </td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

