<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" ><img src="images/aquitas_optical.gif" width="117" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td  class="text">Acuitas Optical is the ultimate Patient Relationship Management for independent opticians.

                      </td>

                </tr>

                <tr>

                  <td  class="text">Like all Ocuco products, Acuitas Optical is designed to give you the following: 

                 

                    </td>

                </tr>

                <tr>

                  <td class="red_bullet" style="padding-top:5px; "><ul>

                  <li>Optimised practice workflow</li>

                  <li>Reduced costs</li>

                  <li>Time savings</li>

                  <li>Increased sales</li>

                  

                  </ul></td>

                </tr>

                <tr>

                  <td class="text">Our aim is to make your life easier by helping you make more money and save costs and time.

                  <p>Acuitas Optical is designed for the modern optical practice where till functions are<br />operated independently from the patient journey.</p>

                  If you require a fully integrated EPoS till, validated dispensing and stock control, check<br />

                  out <a href="pro_optician_acuitas_retail_overviw.html" target="_blank" style="text-decoration:none;"> Acuitas Retail </a>  </td>

                </tr>

                <tr>

                  <td class="text" style="padding-top:12px;">Acuitas can help you maximise your sales by providing you with a means of enhancing the<br />quality of service you can provide. It has been described by users as &lsquo; The bow on the box &rsquo;.</td>

                </tr>

                <tr>

                  <td class="red_bullet" style="padding-top:8px; ">

                  <ul>

                  <li>Appointment to collection in one application </li>

                  <li>Comprehensive Examinations with graphics </li>

                  <li>Thorough Patient Recall &ndash; using all modes of communication, letter, SMS,<br />email and phone</li>

                  <li>Marketing tool for effective target communications with your patients</li>

                  <li>Management visibility performance throughout the practice from people to<br />products</li>

                  <li>Links with Fundus and anterior cameras allowing you to share expensive<br />equipment </li>

                  <li>Links with Focimeters, phoroptors, autorefractors and tonometers for quick<br />data entry</li>

                  <li>Paperless saves space, time and bottom line costs</li>

                  </ul></td>

                </tr>

                <tr>

                  <td class="text" style="padding-top:12px;">Acuitas Optical is recommended for the independent optician with one or two consulting rooms who:</td>

                </tr>

                <tr>

                  <td class="red_bullet" style="padding-top:5px; ">

                  <ul>

                  <li>Want their practice to run more efficiently and paperlessly.</li>

                  <li>Desire to be at the leading edge</li>

                  <li>Want to enable staff to provide a better level of patient service while<br />optimising the use of their own time</li>

                  <li>Welcome low &ndash; burden communication with patients</li>                  

                  </ul>

                  

                  </td>

                </tr>

                <tr>

                  <td class="text" style="padding-top:12px;">Acuitas Optical is also a must for practices where it is necessary to:</td>

                </tr>

                <tr>

                  <td class="red_bullet" style="padding-top:5px; ">

                  <ul>

                  <li>Share expensive diagnostic equipment. </li>

                  <li>Ensure that patient data is secure.</li>

                  </ul>

                  </td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

