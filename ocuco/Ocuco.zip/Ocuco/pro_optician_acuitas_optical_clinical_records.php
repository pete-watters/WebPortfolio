<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" valign="top" ><img src="images/clinical_records_ao.gif" width="287" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                

                <tr >

                  <td class="red_bullet">

                  <ul>

                  <li>As standard, Acuitas comes with a full Clinical Records module that is designed to<br />

                    totally replace the paper record.</li>

                  <li>Audit trails to provide secure history of data entry. </li>

                  <li>Fully configurable examination checklists.</li>

                  <li>Easy creation of new examination categories and pages.</li>

                  <li>Prints hard copy of clinical record &ndash; therefore the system can easily be used by<br />locums and other staff with limited computer expertise.</li>

                  <li>Full recording of clinic outcome (dispensing, no dispensing, FTA etc) &ndash; can be used<br />as basis for locum / OO payments and key indicator analysis.</li>

                  <li>Complete referral letter management.</li>

                  <li>Self learning lists &ndash; Each clinical entry can be saved and used generically for<br />patient examinations.</li>

                  <li>Can be linked to the full Clinical Records module for a true &lsquo; paperless practice &rsquo;.</li>

                  <li>Sight test fee (and supplementary fees) assigned automatically at end of test.</li>

                  <li>Prompts for addition of examination fees to Px sales screen, e.g. NHS Exam, Private<br />exam plus Imaging etc.</li>

                  <li>Provides a seamless link between clinical and retail within the practice.</li>

                  </ul>                    </td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

