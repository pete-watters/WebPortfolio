<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 
            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" valign="top" ><img src="images/what_our_user_say.gif" width="141" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1"  height="8"/></td>

                </tr>

                

                <tr >

                  <td class="text" style="margin-top:0px;">&quot; In 1993 when I met Ocuco I had looked around for a computer system that was up to date with<br />other technology in the industry. I took a chance on a new company with a good product and<br />ten years later I am still happy with that decision.&quot;                  </td>

                </tr>

                <tr>

                  <td class="text" ><strong>Ocuco&rsquo;s first customer, Jim Tunney, Tunney Opticians, Finglas, Co. Dublin</strong></td>

                </tr>

                <tr>

                  <td class="text" style="padding-top:12px;">&quot; Excellent Clinical Notes, providing easily audited clinical data. Friendly Diary interface, making the best of our time.&quot;</td>

                </tr>

                <tr>

                  <td class="text" ><strong>David Clacher, F.A. Schwartz Optometrists, Wrexham, Clwyd</strong></td>

                </tr>

                <tr>

                  <td class="text" style="padding-top:12px;">&quot; Acuitas offers excellent Clinical Notes, providing easily audited clinical data, a<br />

                    friendly Diary, allowing to schedule patients most effectively, a dispensing module to help<br />speed up ordering, and many other features, but it remains simple to use.&quot;</td>

                </tr>

                <tr>

                  <td class="text"><strong>Mairead O&rsquo;Leary FAOI, Mairead O&rsquo;Leary Opticians, Rathmines, Co. Dublin</strong></td>

                </tr>

                <tr>

                  <td class="text" style="padding-top:12px;">&quot; Acuitas improves practice efficiency and saves admin/secretarial time. At last, notes<br />

                    taken on patient records remain legible! Overall, Acuitas&trade; was a very suitable purchase<br />for me.&quot;</td>

                </tr>

                <tr>

                  <td class="text"><strong>Dr. Kevin Tempany, Ranelagh Eye Centre, Dublin 6</strong></td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

