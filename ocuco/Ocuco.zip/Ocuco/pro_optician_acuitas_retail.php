<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" ><img src="images/creation_of_new_patient.gif" width="165" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td >                </td>

                </tr>

                <tr >

                  <td class="text" style="padding-bottom:14px;">Finding your patients while on the phone or serving other customers is part of your daily routine 

                      </td>

                </tr>

                <tr>

                  <td class="red_bullet">It is important for patient search and creation of patients to be:

                  

                  <ul>

                  <li>Fast</li>

                  <li>Reliable</li>

                  <li>Accurate &ndash; no duplications</li>                  

                  </ul>

                  

</td>

                </tr>

                <tr>

                  <td class="bold_text" style="padding-top:14px;">The Patient Search </td>

                </tr>

                <tr>

                  <td class="text">Creating a new patient either through the Diary while making an appointment or through the main application forces the user<br />through the search screen in order to ensure that the patient is not already registered.

</td>

                </tr>

                <tr>

                  <td class="bold_text" style="padding-top:14px;">Key Features</td>

                </tr>

                <tr>

                  <td class="red_bullet" style="padding-top:5px; ">

                  <ul >

                  <li>Search for a patient using one of or a mixture of the following parameters;Full name, Postcode, Address (and<br />parts of), DOB, PID, Last Visit, Telephone no, DD Reference, Alias and Insurance references.

</li>

<li>Incremental search narrows list as you type, you don&rsquo; t have to type the	full name to find a patient</li>

                  

                  </ul>

                  

                  </td>

                </tr>

                <tr>

                  <td class="bold_text" style="padding-top:14px;">Key Benefits</td>

                </tr>

                <tr>

                  <td class="red_bullet" style="padding-top:5px; ">

                  <ul>

                  <li>Quick access to your patients records </li>

                  <li>Never lose a patient, even if you don&rsquo; t remember the name Through the Diary

</li>

                  </ul>

                  </td>

                </tr>

                <tr>

                  <td class="bold_text" style="padding-top:14px;">Key Features</td>

                </tr>

                <tr>

                  <td class="red_bullet" style="padding-top:5px; ">

                  <ul>

                  <li>Search function built into Diary</li>

                  <li>Creation of patients through appointment time slot or search function</li>

                  <li>Postcode lookup integration</li>            

                  </ul>

                  </td>

                </tr>

                <tr>

                  <td class="bold_text" style="padding-top:14px;">Key Benefits</td>

                </tr>

                <tr>

                  <td class="red_bullet" style="padding-top:5px; " >

                  <ul>

                  <li>No need to create a full record for the patient for making an appointment</li>

                  <li>Allows the creation of an appointment before asking the patient all their details, patient just wants to know<br />the date and time first.</li>

                  <li>No need to leave Diary to create a record </li>

                  </ul>

                  </td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

