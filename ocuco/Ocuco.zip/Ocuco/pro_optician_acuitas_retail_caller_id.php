<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 
            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" valign="top" ><img src="images/caller_id.gif" width="61" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td class="text"><p>See which of your customers is calling you and have their record open in Acuitas/Focus<br />before call is answered.  This will make your receptionist&rsquo;s life easier and more<br />productive. Caller ID is a standalone add &ndash; in to Acuitas that connects your computer system<br />to your telephone line and uses the Caller ID data supplied by your telephone operator to<br />identify the caller as one of your patients.</p>

                  When the telephone rings, a dialog box appears on a designated workstation.  This dialog<br />box shows the telephone number, name and date of birth of the patient (if known from the<br />database of course) and the date of their next appointment.  The availability of this<br />information in a condensed format will already save you time.

                  <p>It also shows the history of calls for that patient, and because it does it in a separate<br />window, Caller ID does not disrupt what you were doing in Acuitas. To avail of Caller ID,<br />all the practice needs is a telephone line.  In some areas, you may have to ask your<br />telephone company to enable Caller ID display for you.</p>

                  If your practice is equipped with a telephone system (sometimes called a PABX) with<br />multiple telephone lines, extensions etc, you can specify on installation which extension(s)<br />will be activating Caller ID, and on which workstation.  This way, you can make sure<br />that an incoming call on the Reception desk will not distract an optom in the middle of a<br />refraction.



                  

                  </td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

