<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 
            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" valign="top" ><img src="images/epos_till.gif" width="63" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif"  height="8"/></td>

                </tr>

                <tr>

                  <td>

                  </td>

                </tr>

                <tr >

                  <td >

                 

                    </td>

                </tr>

                <tr>

                  <td class="bold_text" style="padding-bottom:2px;">Overview</td>

                </tr>

                <tr>

                  <td class="text">All information is now available for the user to receive payment.</td>

                </tr>

                <tr>

                  <td class="text" >It important a Till system will:</td>

                </tr>

                <tr>

                  <td class="red_bullet" style="padding-top:5px; ">

                  <ul>

                  <li>Fully integrate with the dispensing module and the product files</li>

                  <li>Be user friendly and intuitive</li>

                  <li>Aid the retail process</li>

                  </ul>

                  </td>

                </tr>

                <tr>

                  <td class="bold_text" style="padding-top:11px;">Key Features</td>

                </tr>

                <tr>

                  <td class="red_bullet" style="padding-top:5px; ">

                  <ul >

                  <li>Ease of use &ndash; Simple and fast transactions</li>

                  <li>Fully integrated with full patient journey</li>

                  <li>VAT receipts available</li>

                  <li>Touch-screen models available</li>

                  </ul>

</td>

                </tr>

                <tr>

                  <td class="bold_text" style="padding-top:11px; padding-bottom:2px;">Key Benefits</td>

                </tr>

                <tr>

                  <td class="red_bullet" style="padding-top:5px; ">

                  <ul >

                  <li>Line by line breakdown of each transaction</li>

                  <li>Till receipts generated on the spot</li>

                  <li>All items can be scanned by barcode, which reduces data entry errors and speeds up the sale</li>

                  <li>Detailed reports available to show fast moving stock, cash book, VAT reports and many more</li>

                  <li>Configurable reporting also available</li>

                  </ul>

                  </td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

