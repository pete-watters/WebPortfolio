<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" valign="top" ><img src="images/installation.gif" width="76" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td class="bold_text">Project Management </td>

                </tr>

                <tr >

                  <td class="text" style="padding-top:2px;">The implementation of a comprehensive practice management system is not a trivial task, and should be carefully considered<br />and planned.

                  <p>We can undertake a full project management service to facilitate the implementation, including the preparation of a schedule<br />of tasks to be performed, and the allocation of responsibilities for each task; the identification of key &lsquo; milestones &rsquo;; and<br />regular review meetings during the implementation to ensure a successful outcome and minimise impact on trade.</p>





                    </td>

                </tr>

                <tr>

                  <td class="bold_text" style="padding-top:17px;">Hardware Specification</td>

                </tr>

                <tr>

                  <td class="text" style="padding-top:2px;"><p>Unlike many of our competitors, we are perfectly happy to supply &lsquo; software only&rsquo; to clients who wish to purchase hardware<br />themselves. This can be particularly useful where a practice already has a good relationship with an existing computer<br />supplier. In these circumstances we can liaise with the proposed supplier to ensure that the hardware is of the appropriate<br />quality and specification to run Acuitas successfully.</p>

</td>

                </tr>

                <tr>

                  <td class="bold_text" style="padding-top:17px;">Data Conversion</td>

                </tr>

                <tr>

                  <td class="text" style="padding-top:2px;">Data stored on previous systems can usually be imported into Acuitas directly with no re &ndash; keying necessary</td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

