<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" valign="top" ><img src="images/nhs_forms.gif" width="87" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td >

                  </td>

                </tr>

                <tr >

                  <td  class="bold_text" style="padding-bottom:2px;">Overview</td>

                </tr>

                <tr>

                  <td class="text">Acuitas changes the usual practice with NHS forms as it does not require the preparation of forms in advance. It saves staff<br />time and effort by only handling the information once. The Rx is entered by the OO in the Rx page and it is then merged into<br />the NHS form along with any other relevant information. Acuitas users generally print the NHS form on a multi-tray duplex<br />printer as part of the handover. This allows them to sign the forms straight away and handover with the patient to the DO. 

</td>

                </tr>

                <tr>

                  <td class="bold_text" style="padding-top:12px;">Features</td>

                </tr>

                <tr>

                  <td class="red_bullet" style="padding-top:5px; ">

                  <ul >

                  <li>Completes all information required on the NHS forms</li>

                  <li>No need for hand writing additional information</li>

                  <li>Prompts to gather correct information</li>                  

                  </ul>

                  </td>

                </tr>

                <tr>

                  <td class="bold_text" style="padding-top:12px;">Benefits</td>

                </tr>

                <tr>

                  <td class="red_bullet" style="padding-top:5px; ">

                  <ul>

                  <li>Saves administration staff time as preparation not required</li>

                  <li>Signature of OO does not have to wait until end of day</li>

                  <li>Reduces returns from claiming authority due to illegibility </li>

                  </ul>

                  </td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

