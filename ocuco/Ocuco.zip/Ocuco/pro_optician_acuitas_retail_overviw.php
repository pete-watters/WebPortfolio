<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" ><img src="images/acquitas_retail.gif" width="94" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td >                </td>

                </tr>

                <tr>

                  <td class="text"> <strong>Acuitas Retail - The Ultimate for Opticians With Vision</strong><br />

                    <p>You are an ophthalmic optician with an eye for business. You want your practice to be managed using the utmost business<br /> 

                      principles and you want your patients, your custoemrs and your staff to contribute to its success, and to your success. </p>

                    <p>You need a software solution for your ophthalmic optician practice that will allow you to manage, control and administer the<br /> 

                      full patient journey, from first contact all the way through the dispense, handover, delivery and payments. </p>

                    <p>But Acuitas Retail is much more than a patient relationship management with an EPoS till.</p>

                    <p>You also want your software to manage stocks, inventory, validate the lens dispensing with stocks available and optimising<br /> 

                      the handover process, maximising dispense value.</p>

                    <p>You have found Acuitas  Retail.</p>

                    <p>Acuitas  Retail is the reference against which you should measure all other software packages. </p>

                    <p>Acuitas  Retail rich feature list, ease of use, reliability and dependability, comtributed to have it regarded as the gold standard<br /> 

                      in the UK and Irish optical markets.</p>

                    <p>Acuitas  Retail can also be further enriched with optional modules and add-ons, most of which can be <a href="online_shop.htm" target="_blank">purchased online</a><br />

                    </p>

                    <p></p></td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

