<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" valign="top" ><img src="images/refraction.gif" width="70" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td class="bold_text">Overview</td>

                </tr>

                <tr>

                  <td>

                    </td>

                </tr>

                <tr>

                  <td class="text">Ocuco have the most comprehensive recording of the refraction. Refractions recorded above those gathered in pre-test are<br />Retinoscopy, Subjective and Rx Given. Where relevant there is distance, near and intermediate recorded with Adds, prisms,<br />bases and PDs. </td>

                </tr>

                <tr>

                  <td class="text" style="padding-top:10px;">It is important for the refraction area of clinical system:</td>

                </tr>

                <tr>

                  <td class="red_bullet" style="padding-top:5px; ">

                  <ul>

                  <li>To be complete</li>

                  <li>To allow fast data entry</li>

                  <li>To aid the Optom in recording data quickly</li>

                  <li>To integrate with other areas of the application such as NHS forms, dispensing etc.</li>

                  </ul>

                  </td>

                </tr>

                <tr>

                  <td class="bold_text" style="padding-top:12px; padding-bottom:2px;">Key Features</td>

                </tr>

                <tr>

                  <td class="red_bullet" style="padding-top:5px; ">

                  <ul>

                  <li>No typing skills required, can use mouse or keyboard</li>

                  <li>Links with consulting room equipment such as phoroptor head for both outputand input</li>

                  <li>Summary showing all Refractions, lensmeter, autorefractor, ret, subjective and Rx Given</li>

                  <li>Keyboard data entry screen for those with typing skills</li>

                  <li>Special page for full history of refraction overall visits line by line</li>

                  <li>Special page for graph representation of Acuity, Sphere and Cyl for patients Subjective and Given<br />prescriptions to aid in communications and interaction with Patient</li>

                  <li>Contact lens prescription page with configurable CL types, up to 24 different parameters</li>

                  </ul>

                  </td>

                </tr>

                <tr>

                  <td class="bold_text" style="padding-top:12px; padding-bottom:2px;">Key Benefits</td>

                </tr>

                <tr>

                  <td class="red_bullet" style="padding-top:5px; ">

                  <ul>

                  <li>All information is easily gathered that is required for dispensing</li>

                  <li>Speedy data entry</li>

                  <li>Links with consulting room equipment make the process accurate and totally integrated</li>

                  </ul>

                  </td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

