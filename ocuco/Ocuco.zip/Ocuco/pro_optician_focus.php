<?php include("pro_header.php")?>
   
<?php include("pro_optician_side_menu.php")?> 

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" ><img src="images/focus.gif" width="40" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="1" /></td>

                </tr>

                <tr>

                  <td class="text"> F.O.C.U.S. meets the challenge of comprehensively computerising optical practices.<br />

                  </td>

                </tr>

                <tr>

                  <td class="text"><p>Designed from the outset to be a totally integrated system it is suitable for any practice,<br />large or small, that wishes to increase net profit, increase efficiency and increase the<br />quality of service offered to patients. It has been designed to be used by all staff<br />members, whatever their level of computer experience, and has a host of unique features<br />designed to deliver both commercial and clinical benefits.</p>

                    Based throughout on Windows technology the system is fully multi &ndash; user, robust &ndash; and has<br />been successfully installed in some of the busiest practices in the UK since the early<br />1990s. It is used to maximise the commercial opportunities available to practices, and will<br />at the same time enable them to maintain and enhance the clinical care and customer service<br />that they are able to offer their patients.

                    <p>The following pages describe just some of the features that can be found in this exciting<br />product. What they cannot show is just how easy to use the system really is. Why not<br />arrange a demonstration at your practice with one of our highly experienced sales team.<br />

                  </p></td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

