<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" ><img src="images/fel_optional_epos_module.gif" width="290" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td > </td>

                </tr>

                <tr >

                  <td> </td>

                </tr>

                <tr>

                  <td class="red_bullet" style="padding-top:5px; "><ul>

                      <li>Fully password protected. </li>

                      <li>Fully integrated with cash drawer and receipt printer &ndash; no need for a separate till.</li>

                      <li>Supports multiple receipt printers and cash drawers per location. </li>

                      <li>Transactions can be entered from any workstation, whether or not receipt printer and<br />

             drawer are attached. </li>

                      <li>Rapid entry of Miscellaneous sales e.g. of solutions or accessories to non-patients. </li>

                      <li>Selection of sales items by PLU [Product Look-Up] code, SKU [stock keeping Unit] code,<br />

              bar code (using scanner) or description &ndash; no separate code lists required. </li>

                      <li>Product details can be maintained centrally and downloaded overnight. </li>

                      <li>Unlimited sales items per transaction; unlimited payments and payment methods per<br />

               transaction. </li>

                      <li>Full sales history for each patient can be viewed at any time; the sales history includes<br />

             details of all goods and services supplied; any refunds given, and any discounts given and<br />

              reasons for them. </li>

                      <li>Can combine user defined payment methods &ndash; e.g. offer vouchers and payments by insurance<br />

              companies or employers &ndash; with standard payment methods, e.g. cash and credit cards.</li>

                      <li>Payments by cash prompt for amount tendered &ndash; system then calculates and displays change<br />

              required.</li>

                      <li>Sales transactions are automatically generated from dispensing.</li>

                      <li>NHS and private sight test fees added automatically from Clinic details ensuring that<br />

              they cannot be overlooked.</li>

                      <li>NHS voucher and fee reconciliation feature ensures that all NHS forms are accounted for<br />

              and submitted in a timely manner.</li>

                      <li>Gross margin reporting at point of sale on all sales transactions. </li>

                      <li>Automated generation of spectacle orders and CL orders from confirmed sales. </li>

                      <li>Closedown feature to assign end-of-day sales to following day whilst cashing-up.</li>

                      <li>Handles entry of returned cheques correctly. </li>

                      <li>Separate entry of daily bankings, PDQ, credit transfer and petty cash values &ndash; allows<br />

              centralised reconciliation of transactions against bank accounts and correct integration<br />

              with a &lsquo;double-entry&rsquo; bookkeeping system such as Sage. </li>

                      <li>Full audit trail of all transactions available. </li>

                      <li>Multiple VAT methodologies supported. </li>

                  </ul></td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

