<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 
            <td width="30">&nbsp;</td>
            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->
              <table width="685" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td height="21" background="images/line_bg.jpg" ><img src="images/ao_caller_id.gif" width="264" height="20" /></td>
                </tr>
                <tr>
                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>
                </tr>
                <tr>
                  <td > </td>
                </tr>
                <tr >
                  <td> </td>
                </tr>
                <tr>
                  <td class="text"><strong>See which of your customers is calling you and have their record open in Focus before the call is answered.</strong>
<p>
This add-on is designed to make your receptionist�s life easier and more productive.<br />
Caller ID is a standalone add-on module that connects your computer system to your <br />
telephone line and uses the Caller ID data supplied by your telephone operator to <br />
identify the caller as one of your patients.</p>

<p>When the telephone rings, a new form appears on the designated workstation.<br />
This form shows the telephone number, name and date of birth of the patient<br />
(if known from the database of course) and the date of their next appointment.</p>
<p>The availability of this information in a condensed format will already save you time.<br />
It also shows the history of calls for that patient, and because it does it<br />
in a separate window, Caller ID does not disrupt what you were doing in Focus.</p>
<p>
To avail of Caller ID, all the practice needs is a telephone line.  </p>
<p>If the practice is equipped with a telephone system (sometimes called a PABX)<br />
with multiple telephone lines, extensions etc, you can specify on installation <br />
which extension(s) will be activating Caller ID, and on which machine.  <br />
This way, you can make sure that an incoming call on the Reception desk<br />
will not distract an optom in the middle of a refraction.</p>


</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
              </table>
            <!-- InstanceEndEditable --></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      
      
      
      
      
      
    </table></td>
  </tr>
  <tr>
    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>
                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>
                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>
                      </tr>
                    </table></td>
                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>
                  </tr>
              </table></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table>

</body>
<!-- InstanceEnd --></html>
