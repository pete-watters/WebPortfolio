<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" ><img src="images/ao_eyeplan.gif" width="286" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td > </td>

                </tr>

                <tr >

                  <td> </td>

                </tr>

                <tr>

                  <td class="text"><table width="100%"  border="0" cellspacing="0" cellpadding="0">

                    <tr>

                      <td width="100"><img src="images/eyeplan.jpg" width="80" height="80" /></td>

                      <td valign="top" class="text">This add-on module allows Eyeplan Associate opticians to administer Eyeplan from<br /> 

                        within F.O.C.U.S.</td>

                    </tr>

                  </table></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td class="text"> The features are as a result of collaboration between the Focus development team and Eyeplan that dates back to<br /> 

                    2005. The collaboration is as result of a shared desire to improve the optics market, both companies believe that the<br /> 

                    optics market in the UK needs to evolve to be competitive and this new set of features will help independent opticians<br /> 

                    achieve exactly that. </td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td class="red_bullet">The main features of the Eyeplan F.O.C.U.S. module are :<br />





         <ul><li>allows patient details to be automatically entered into the Eyeplan registration form</li>



         <li> administers patient membership fees</li>



        <li>calculates automatically Eyeplan incentive pricing.</li></ul></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td class="text"> Eyeplan is an effective and very successful business strategy for opticians. Eyeplan is in effect a network of independent<br /> 

                    opticians who offer the Eyeplan eye care scheme to patients, who in return for a few pounds per month get such benefits<br /> 

                    as unlimited eye examinations, lower costs or free eye wear and damage protection for their glasses. There are<br /> 

                    approximately 200 opticians in the Eyeplan network and tens of thousands of individual members across the UK, with<br /> 

                    significant expansion set to take place over the next few years. </td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td class="text"> Eyeplan is the AOP approved supplier for monthly payment eye care schemes. </td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td class="text"><strong>Eyeplan Contact:</strong><br />





Chris Clemence, Commercial Director, Eyeplan Ltd<br />





<strong>Phone&nbsp; :</strong>&nbsp; 01761 414142     <br />





<strong>Mobilz&nbsp; :</strong> 07809 617797<br />





<strong>E-mail &nbsp;: </strong><a href="mailto:chris.clemence@eyeplan.co.uk">chris.clemence@eyeplan.co.uk</a></td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

