<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 
            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" ><img src="images/ao_patient_pix.gif" width="286" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td > </td>

                </tr>

                <tr >

                  <td> </td>

                </tr>

                <tr>

                  <td height="8" class="text"><strong>Patient Pix, straightforward dispensing assistance.</strong>

                      <p> The optician's conundrum: patients want to see themselves wearing their new frames, but they <br />

        cannot see clearly their image in the mirror. PatientPix is a simple, low cost solution designed to<br />

        satisfy the need within an optical practice for visual dispensing. PatientPix allows you to take digital <br />

        photos of your customers wearing a variety of different spectacle frames and present the photos in a format<br />

        that allows the patient to compare the results on screen. </p>

                      <p> PatientPix can be configured to display either 9 or 4 photos per page. </p>

                      <p>The key to the success of PatientPix is in its simplicity: simple to purchase, easy to install and intuitive to use,<br />

                        requiring no additional training. PatientPix will work with any Windows compatible webcam, but it must be capable<br />

        of taking images at least 800x600 pixels at 30fps (frames per second). <br />

        This is also known as a VGA webcam. Picture size and quality are entirely dependant on the Webcam used, and there are lots<br />

        of models today to choose from at varying prices.</p>

                      <p>You can <a href="online_shop.htm" target="_blank">purchase Patient Pix online</a> on our secure website, or by calling your Account Manager:<br />

                          <br />

                          <strong>From Ireland call</strong> &nbsp;&#8212;&nbsp; 1800 927 191<br />

                          <strong>From the UK dial &nbsp;</strong> &#8212; &nbsp;0800 912 1004</p>

                      </td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/ppix.jpg" width="400" height="287" /></td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

