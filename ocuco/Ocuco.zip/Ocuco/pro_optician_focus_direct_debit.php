<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" ><img src="images/ff_direct_debit.gif" width="286" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td > </td>

                </tr>

                <tr >

                  <td> </td>

                </tr>

                <tr>

                  <td class="red_bullet" style="padding-top:5px; "><ul>

                      <li>Fully integrated with ordering and PoS systems. <br />

                      </li>

                      <li>Can be used to control standing orders, direct debits, or a mixture of both &ndash; so you can move patients from one to the<br />other gradually over time. </li>

                      <li>System will print SO and SO amendment forms; also Direct Debit mandate forms, already completed with patient and bank<br />details.</li>

                      <li>Bank details are validated automatically, reducing rejected payments; bank address details are completed from postcode<br />entry. </li>

                      <li>System generates direct debits automatically, then (optionally) forwards them to a central location for consolidation<br />and onward transmission to BACs.</li>

                      <li>Users can record rejected payments, cash receipts and goods supplied, so that a patient&rsquo;s balance can be displayed/printed<br />at any time.</li>

                      <li>Report on total patient balances at any time.</li>

                      <li>Entry of cash payments (e.g. to make up for a rejected direct debit) fully integrated with the end-of-day cashing &ndash; up<br />procedure.</li>

                      <li>Next payment date and next amount can be amended at any time, allowing temporary increases, (e.g. to pay for specs on<br />credit), or decreases, (e.g. to give a patient a payment holiday.) </li>

                      <li>The system can be used to order lenses and solutions automatically as they become due. </li>

                      <li>Patient accounts can be debited automatically with supply of care element &ndash; reduces VAT liability and maintains correct <br />patient balances. </li>

                      <li>Can report at any time on <br />

              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;a) monies received into each patient&rsquo;s Direct Debit account, and <br />

              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;b) all goods and services supplied during the same period &ndash; to allow accurate accounting and VAT entries </li>

                  </ul></td>

                </tr>

                <tr>

                  <td >&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

