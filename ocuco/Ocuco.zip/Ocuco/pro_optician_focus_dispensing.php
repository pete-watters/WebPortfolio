<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" ><img src="images/ff_dispensing.gif" width="290" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td > </td>

                </tr>

                <tr >

                  <td> </td>

                </tr>

                <tr>

                  <td class="red_bullet" style="padding-top:5px; "><ul>

                      <li>Fully integrated with patient Rx &ndash; eliminates transcription and transposition errors. </li>

                      <li>Multiple estimates per patient, allows any combination of confirmed and unconfirmed<br />dispensings. </li>

                      <li>Each dispensing can be based on original or modified Rx, automatically carried through to<br />the order. </li>

                      <li>Each dispensing can be based on a selected frame, that may or may not be held in stock;<br />can also be used to dispense reglazes (with patient&rsquo;s own frame clearly identified on the<br />resulting order.) </li>

                      <li>Frames can be ordered at point of dispense &ndash; a discrete warning is provided if the frame<br />to be ordered has been discontinued </li>

                      <li>Select frame(s) from the frame catalogue either by style, size and colour or barcode <br />(with optional bar code scanner).</li>

                      <li>System selects lenses according to the availability of the power, (plus and minus cyl<br />supported), spectacle type, lens material and blank size required, ensuring that only valid<br />lenses are selected. </li>

                      <li>Displays favoured pairs of lenses in descending order of cost, together with<br />descriptive/sales information, maximising dispensing value. </li>

                      <li>Allows dispensing of individual lenses, including different lenses for each eye, e.g.<br />varifocal in one eye, balance sv in the other. </li>

                      <li>Allows multiple finishes per dispense.</li>

                      <li>Estimates include the value of vouchers issued; can also incorporate additional frame<br />discounts for NHS patients.</li>

                      <li>Optional lens pricing according to NHS voucher values. </li>

                      <li>Multiple discounts per dispense, including itemised discounts off frame, lenses, extras<br /> and overall.</li>

                      <li>Prompts for entry of PDs when confirming an estimate. </li>

                      <li>Automatic calculation of suggested deposit &ndash; maximises cash flow. </li>

                  </ul></td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

