<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 
            <td width="30">&nbsp;</td>
            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->
              <table width="685" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td height="21" background="images/line_bg.jpg" ><img src="images/appoinments.gif" width="98" height="20" /></td>
                </tr>
                <tr>
                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>
                </tr>
                <tr>
                  <td > </td>
                </tr>
                <tr >
                  <td> </td>
                </tr>
<tr>
*** MOVE THIS TEXT BELOW THE HEADER BUT BEFOORE THE BULLETS *** The Entry Level version of Focus already offers advanced Appointments functions to help you keep your practice busy and maximise the use of your consulting room.</td>
                <tr>
                  <td class="red_bullet" style="padding-top:5px; ">
                  <ul>
                  <li>View details of up to six clinics at a time (up to 6 clinics for a single optician, or<br />all the clinics on a single day for many opticians.)</li>
                  <li>View next day&rsquo;s/next week&rsquo;s clinics at the click of a mouse.</li>
                  <li>Default start time, lunch breaks, appointment times stored against each member of staff.</li>
                  <li>User defined colour coded appointment types, e.g. Eye Exam; Eye Exam and CL Checkup;<br />Diabetic Screening etc </li>
                  <li>Adjust clinic start and appointment start times, and lengths of appointment directly</li>
                  <li>Allow insertion of additional appointments, e.g. additional 5 minute CL check.</li>
                  <li>Assign existing patients to an appointment with a single click.</li>
                  <li>Find vacant appointment for new patient before asking for patient details.</li>
                  <li>Add details of new patient (including duplicate checking) directly from the Diary window.</li>
                  <li>View next day&rsquo;s/next week&rsquo;s clinics at the click of a mouse. </li>
                  <li>Default start time, lunch breaks, appointment times stored against each member of staff.</li>
                  <li>Print appointment confirmation slips.</li>
                  <li>Print clinic list at any time.</li>
                  <li>Unique &lsquo; Future Capacity &rsquo; report, showing percentage of utilisation of examination<br />facilities, (can be consolidated for multiple branches).</li>
                  <li>Send SMS (mobile text) messages confirming appointment details automatically.</li>
                  </ul>                  </td>
                </tr>
                
                <tr>
                  <td>&nbsp;</td>
                </tr>
                </table>
            <!-- InstanceEndEditable --></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      
      
      
      
      
      
    </table></td>
  </tr>
  <tr>
    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>
                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>
                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>
                      </tr>
                    </table></td>
                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>
                  </tr>
              </table></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table>

</body>
<!-- InstanceEnd --></html>
