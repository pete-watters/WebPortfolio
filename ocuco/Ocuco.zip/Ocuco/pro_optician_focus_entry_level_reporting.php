<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" ><img src="images/fel_reports.gif" width="201" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td > </td>

                </tr>

                <tr >

                  <td> </td>

                </tr>

                <tr>

                  

<td  class="text" style="padding-top:5px;">The reports listed below are just a small selection of the reports provided with Entry Level Focus - some of them with come with the optional EPOS function of Entry Level Focus (available as standard on <a href "pro_optician_focus_full_landing.html"> Full Focus</a>:</td>

                      <td class="red_bullet" style="padding-top:5px; "></td>

                </tr>

                <tr>

                  <td class="red_bullet" style="padding-top:5px; ">

				  <ul>

                      <li>Clinic/OO reporting.</li>

                      <li>Cash analysis by week /date. </li>

                      <li>Sales analysis by week/date. </li>

                      <li>Bank/PDQ/FPC Reconciliation. </li>

                      <li>Departmental sales analysis by week/date. </li>

                      <li>Sales by date/sales type.</li>

                      <li>Audit trail of all transactions. </li>

                      <li>Cash by date/payment type. </li>

                      <li>Outstanding balances.</li>

                      <li>Gross margin by date/sales type.</li>

                      <li>Gross margin by pairs of spectacle by date </li>

                      <li>Refunds/write-offs given by date.</li>

                      <li>VAT</li>

                  </ul>				  </td>

                </tr>

                <tr>

                  <td  class="text" style="padding-top:5px;">In addition, bespoke reports can be created to user&rsquo;s requirements. Alternatively query<br />

                    tools can be provided so that users can create heir own reports without compromising the<br />

                    integrity of the FOCUS data. </td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

