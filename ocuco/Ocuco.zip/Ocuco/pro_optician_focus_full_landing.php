<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 
            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" ><img src="images/full_focus.gif" width="219" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="1" /></td>

                </tr>

                <tr>

                  <td class="text"> The Full version of FOCUS meets the challenge of comprehensively computerising optical practices.<br />

                  </td>

                </tr>

                <tr>

                  <td class="text"><p>Designed from the outset to be a totally integrated system it offers the agility to be suitable for any practice,<br />large or small, that wishes to increase net profit, increase efficiency and increase the <br />quality of service offered to patients, while adding conveninece to their operations, EDI and till procedures, and offering a better and more comprehensive service to te patients. Like its Entry Level sister product, it has been designed to be used by all staff <br />members, irrespective of their level of computer expertise and offers many unique features <br />designed to deliver both commercial and clinical benefits.</p>

                    Based throughout on Windows technology the system is fully multi &ndash; user, robust &ndash; and has<br />been successfully installed in some of the busiest practices in the UK since the early<br />1990s. It is used to maximise the commercial opportunities available to practices, and will<br />at the same time enable them to maintain and enhance the clinical care and customer service<br />that they are able to offer their patients.</p>

If you already have Focus Entry Level, you can <a href "http://uk.classcalendar.biz/ocucorelcon/public?cmd=cart-add&ofrId=PRO-0000000034&quantity=1" target=_blank> purchase Full Focus online</a>. Our online shop also offers convenient <a href "http://uk.classcalendar.biz/ocucorelcon/public?cmd=crs-list&grpId=GRP-0000000040" target=_blank>add-ons</a> that can be purchased online.</p>

                    <p>The following pages describe just some of the features that can be found in this exciting<br />product. What they cannot show is just how easy to use the system really is. Why not<br />arrange a demonstration at your practice with one of our highly experienced sales team.<br />

                  </p></td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

