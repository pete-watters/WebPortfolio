<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" ><img src="images/ff_patients_records.gif" width="290" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td > </td>

                </tr>

                <tr >

                  <td> </td>

                </tr>

                <tr>

                  <td class="red_bullet" style="padding-top:5px; "><ul>

                      <li>Clear, well designed display using large fonts &#8212; so all the relevant information can<br />

             easily be seen at a glance without needing to be carefully &lsquo;studied&rsquo;. </li>

                      <li>Instant record retrieval on surname, Patient ID, date of birth or any part of forename,<br />

             surname, and address. </li>

                      <li>Full searching facilities by multiple fields, e.g. postcode, address lines or telephone<br />

             numbers. </li>

                      <li>Full name and address details (four address lines plus postcode/zip code and email<br />

               address), two telephone numbers plus mobile. </li>

                      <li>Automated postcode lookup &#8212; allows rapid input of address details of new patients.</li>

                      <li>Automatic checking of patients surname and date of birth to minimise duplicated patient details.</li>

                      <li>GP/Ophthalmologist list.</li>

                      <li>User defined analysis codes.</li>

                      <li>Two user definable fields (e.g. loyalty scheme membership number)</li>

                      <li>Free form notes field. </li>

                      <li>Letter writing facility, integrated with free form notes capability to record all<br />

              contacts with patient.</li>

                      <li>Automated printing of NHS forms. </li>

                      <li>Automatically updated branch-based or central Recall facility. </li>

                  </ul></td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

