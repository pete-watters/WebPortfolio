<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" ><img src="images/ff_patients_rx.gif" width="290" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td > </td>

                </tr>

                <tr >

                  <td> </td>

                </tr>

                <tr>

                  <td class="red_bullet" style="padding-top:5px; "><ul>

                      <li>Unlimited RXs per patient &#8212; provides full clinical history. </li>

                      <li>Default to plus or minus cyl, either form can be transposed at ordering stage. </li>

                      <li>Prints a hard copy of clinical record &#8212; making the system easy to use by locums and staff<br />not used to computers. </li>

                      <li>Full recording of clinic outcome (dispensing, no dispensing, FTA etc) &#8212; can be used as<br />basis for locum/OO payments performance analysis. </li>

                      <li>Referral flag &#8212; enables busy optoms to print list of all patients for whom referrals must be written.</li>

                      <li>Free text Clinical Notes field - unlimited text entry, contents can also be incorporated<br />within a GP Referral letter to save time and avoid duplication.</li>

                      <li>Full integration with Point Of Sale system, so that it prompts for addition of<br />examination fees to px sales screen, e.g. NHS Exam, Private exam plus Imaging etc. </li>

                      <li>Can be linked to the full Clinical Records module for a true &lsquo; paperless practice. &rsquo;</li>

                  </ul></td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

