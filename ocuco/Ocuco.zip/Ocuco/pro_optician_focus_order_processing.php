<?php include("header.php")?>
   
<?php include("products_side_menu.php")?> 

            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" ><img src="images/ff_order_processing.gif" width="286" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td > </td>

                </tr>

                <tr >

                  <td> </td>

                </tr>

                <tr>

                  <td class="red_bullet" style="padding-top:5px; "><ul>

                      <li>Purchase orders can either be raised manually (e.g. for frame stock and miscellaneous<br />sales items) or generated automatically (for spectacles, replacement frames, contact lenses<br />and repairs.) <br />

                      </li>

                      <li>All spectacle purchase orders clearly identify the patient for whom the items were<br />purchased. </li>

                      <li>Spectacle purchase orders are automatically updated when finished jobs received.</li>

                      <li>Automatic entry of goods received against purchase orders &ndash; updates stock levels<br />instantly.</li>

                      <li>Manual entry of stock receipts &ndash; allows entry of different quantities from those ordered.</li>

                      <li>Purchase invoice reconciliation &ndash; allows instant comparison between goods ordered, goods<br />received and goods invoiced, ensuring that the practice only pays for what has been<br />ordered, and at the agreed price. </li>

                      <li>Purchase invoice entry allows entry of additional items e.g. P &amp; P, Insurance, and also<br />addition of VAT.</li>

                      <li>Notes can be held against invoices under dispute.</li>

                      <li>Confirmed invoices can be batched and input directly or downloaded to a purchase ledger,<br />eliminating re &ndash; keying and transcription errors. </li>

                  </ul></td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

