<?php include("header.php")?>
   
<?php include("pro_optician_side_menu.php")?> 
            <td width="30">&nbsp;</td>

            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->

              <table width="685" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td height="21" background="images/line_bg.jpg" ><img src="images/overview.gif" width="67" height="20" /></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td class="text">
                  
                  <p>When it comes to choosing the optimum practice management software, Ocuco offer you the widest choice of any supplier on the market, bar none.</p>

                    <p>You have a choice between three class-leading software suites and Ocuco will even give you a choice of payment methods. The choice is yours.</p></td>

                </tr>

                <tr>

                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td class="text"><strong>Acuitas Optical </strong><br />

                    Integrated paperless clinical records with dispensing for high street opticians with two or more consulting rooms.</td>

                </tr>

                <tr>

                  <td height="12"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td class="text"><strong>Acuitas Retail </strong><br />

                    Integrated paperless clinical records with validated dispensing and EPoS for high street opticians </td>

                </tr>

                <tr>

                  <td height="12"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td class="text"><strong>Acuitas Imaging </strong><br />

                    Digital Imaging, obtain clinical images from linked equipment (fundus cameras, perimeter cameras, etc) manipulate and analyse them, then store them with the patient's clinical record </td>

                </tr>

                <tr>

                  <td height="12"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td class="text"><strong>FOCUS</strong><br />

                    Patient relationship management for high street opticians. FOCUS is designed to be feature-rich, yet easy to use with minimum computer expertise</td>

                </tr>

                <tr>

                  <td height="12"><img src="images/spacer.gif" width="1" height="8" /></td>

                </tr>

                <tr>

                  <td class="text"><strong>Acuitas Enterprise</strong><br />

                    Global visibility and management solution for chains of optical stores. Highly scalable, it is successfully deployed in large international installations (over 200 stores) and is equally at home in much smaller regional and local chains.</td>

                </tr>

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            <!-- InstanceEndEditable --></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

      

      

      

      

      

      

    </table></td>

  </tr>

  <tr>

    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">

            <tr>

              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">

                  <tr>

                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>

                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">

                      <tr>

                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>

                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>

                      </tr>

                    </table></td>

                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>

                  </tr>

              </table></td>

            </tr>

        </table></td>

      </tr>

      <tr>

        <td>&nbsp;</td>

      </tr>

    </table></td>

  </tr>

</table>



</body>

<!-- InstanceEnd --></html>

