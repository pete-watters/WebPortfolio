<tr>

        <td height="24"></td>

      </tr>

      <tr>

        <td><table width="932" border="0" cellspacing="0" cellpadding="0">

          <tr>

            <td width="2">&nbsp;</td>

            <td width="215" valign="top"><!-- InstanceBeginEditable name="navigation" -->

              <table width="100%" border="0" cellspacing="0" cellpadding="0" background="images/left_tab_horizntal_bg.jpg">

                <tr>

                  <td width="16" height="35"><img src="images/left_tab_top_left_cnr.jpg" width="16" height="35" /></td>

                  <td height="35" background="images/left_tab_bg.jpg"><img src="images/products_for_img.jpg" width="70" height="10" /></td>

                  <td width="14" height="35"><img src="images/left_tab_top_rght_cnr.jpg" width="14" height="35" /></td>

                </tr>

                <!--tr>

                <td width="16" height="11"><img src="images/inner_pg_top_lft_cnr.jpg" width="16" height="11" align="top" /></td>

                <td height="11"><img src="images/inner_pg_tab_top_img.jpg" width="185" height="11" align="top" /></td>

                <td width="14" height="11"><img src="images/inner_pg_top_right_cnr.jpg" width="14" height="11" align="top" /></td>

              </tr-->

                <tr>

                  <td colspan="3" class="left_nav">&nbsp;</td>

                </tr>

                <tr>

                  <td colspan="3" class="left_nav"><a href="pro_optician_overview.php" class="top">Opticians</a></td>

                </tr>
    <tr>
                  <td colspan="3"></td>
                </tr>
                <tr>
                  <td colspan="3" class="left_nav2" ><a href="pro_optician_acuitas.php" class="selected" >Acuitas</a></td>
                </tr>
                <tr>
                  <td colspan="3" class="left_nav3" ><a href="pro_optician_acuitas_optical.php" class="selected">Acuitas Optical</a></td>
                </tr>
                <tr>
                  <td colspan="3" class="left_nav3" ><a href="pro_optician_acuitas_retail_overviw.php" >Acuitas Retail</a></td>
                </tr>
                <tr>
                  <td colspan="3" class="left_nav3" ><a href="pro_optician_add_on.php"> Acuitas Add-Ons</a></td>
                </tr>
                <tr>
                  <td colspan="3" class="left_nav3" ><a href="pro_optician_acuitas_imaging_lite.php" >Acuitas Imaging Lite</a></td>
                </tr>
                <tr>
                  <td colspan="3" class="left_nav3" ><a href="pro_optician_acuitas_enterprise.php" >Acuitas Enterprise</a></td>
                </tr>
                
                
                <tr>
                  <td colspan="3" class="left_nav2" ><a href="pro_optician_focus.php" class="selected">Focus</a></td>
                </tr>
                <tr>

                  <td colspan="3" class="left_nav3" > <strong><a href="pro_optician_focus_entry_level_landing.php">Focus-Entry Level</a></strong> </td>

                </tr>

                <tr>

                  <td colspan="3" class="left_nav3" > <a href="pro_optician_focus_full_landing.php">Focus-Full</a></td>

                </tr>

                <tr>

                  <td colspan="3" class="left_nav3" > <a href="pro_optician_focus_clinical_records_landing.php">Focus-Clinical Records</a> </td>

                </tr>

                <tr>

                  <td colspan="3" class="left_nav3" > <a href="pro_optician_focus_addons_landing.php">Focus-Add-Ons</a> </td>

                </tr>
                
                
                
                
                
                <tr>

                  <td colspan="3" class="left_nav"><a href="pro_optical_labs_overview.php">Optical Labs</a></td>

                </tr>
                
                <tr>
                  <td colspan="3" class="left_nav"><a href="pro_opthalmologist_overview.php" >Ophthalmologists</a></td>

                </tr>

                
                <tr>

                  <td colspan="3" >&nbsp;</td>

                </tr>

                <tr>

                  <td width="16" height="20"><img src="images/left_tab_bttm_lft_cnr.jpg" width="16" height="20" /></td>

                  <td height="20"><img src="images/left_tab_bott_img.jpg" width="185" height="20" /></td>

                  <td width="14" height="20"><img src="images/left_tab_bttm_rght_cnr.jpg" width="14" height="20" /></td>

                </tr>

              </table>
              
              <!-- InstanceEndEditable --></td>



      

            <!-- InstanceEndEditable --></td>