<?php include("pro_header.php")?>

      <tr>
        <td height="24"></td>
      </tr>
      <tr>
        <td><table width="932" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="2">&nbsp;</td>
            <td width="215" valign="top"><!-- InstanceBeginEditable name="navigation" -->
              <table width="100%" border="0" cellspacing="0" cellpadding="0" background="images/left_tab_horizntal_bg.jpg">
                <tr>
                  <td width="16" height="35"><img src="images/left_tab_top_left_cnr.jpg" width="16" height="35" /></td>
                  <td height="35" background="images/left_tab_bg.jpg"><img src="images/products_for_img.jpg" width="70" height="10" /></td>
                  <td width="14" height="35"><img src="images/left_tab_top_rght_cnr.jpg" width="14" height="35" /></td>
                </tr>
                <!--tr>
                <td width="16" height="11"><img src="images/inner_pg_top_lft_cnr.jpg" width="16" height="11" align="top" /></td>
                <td height="11"><img src="images/inner_pg_tab_top_img.jpg" width="185" height="11" align="top" /></td>
                <td width="14" height="11"><img src="images/inner_pg_top_right_cnr.jpg" width="14" height="11" align="top" /></td>
              </tr-->
                <tr>
                  <td colspan="3" class="left_nav">&nbsp;</td>
                </tr>
                <tr>
                  <td colspan="3" class="left_nav"><a href="pro_optician_overview.php" class="top">Opticians</a></td>
                </tr>
                <tr>
                  <td colspan="3" class="left_nav"><a href="pro_optical_labs_overview.php">Optical Labs</a></td>
                </tr>
                <tr>
                  <td colspan="3" class="left_nav"><a href="pro_opthalmologist_overview.php">Ophthalmologists</a></td>
                </tr>
                <tr>
                  <td colspan="3" >&nbsp;</td>
                </tr>
                <tr>
                  <td width="16" height="20"><img src="images/left_tab_bttm_lft_cnr.jpg" width="16" height="20" /></td>
                  <td height="20"><img src="images/left_tab_bott_img.jpg" width="185" height="20" /></td>
                  <td width="14" height="20"><img src="images/left_tab_bttm_rght_cnr.jpg" width="14" height="20" /></td>
                </tr>
              </table>
            <!-- InstanceEndEditable --></td>
            
            
            <td width="30">&nbsp;</td>
            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->
              <table width="685" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td height="21" background="images/line_bg.jpg" ><img src="images/products.gif" width="60" height="20" /></td>
                </tr>
                <tr>
                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>
                </tr>
                <tr>
                  <td class="text">Here's what Software With Vision is about.  Ocuco products are regarded as the gold standard in the UK and Irish optical markets.  <a href="pro_opthalmologist_acuitas_imaging.php">Acuitas Imaging</a> is also the market leading imaging software, unique in its ability to interface with both Ocuco product lines, <a href="pro_optician_acuitas_optical.php">Acuitas</a> and <a href="pro_optician_focus.php">Focus</a>. The standalone product <a href="pro_optician_acuitas_imaging_lite.php">Acuitas Imaging Lite</a> is an imaging solution for those practices who have a different method to manage patients, and want most of the imaging features of Acuitas Imaging but limited practice/patient management.
                    <p>For independent opticians and optical chains, Ocuco develops and markets two of the most comprehensive ranges of retail practice management software on the market</p></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td><table width="100%"  border="0" cellspacing="0" cellpadding="0">
                    <tr>
                      <td width="100" valign="top"><a href="pro_optician_acuitas_optical.php"><img src="images/p1.jpg" width="80" height="80" vspace="4" border="0" /></a></td>
                      <td width="230" valign="top" class="text" style="line-height:18px; "><a href="pro_optician_acuitas_optical.php">Acuitas</a>, the practice management<br /> 
                        solution for larger practices with two<br /> 
                        or more consulting rooms and<br /> 
                        for national chains</td>
                      <td width="100" valign="top"><a href="pro_optician_focus.php"><img src="images/p2.jpg" width="80" height="80" vspace="4" border="0" /></a></td>
                      <td width="220" valign="top" class="text" style="line-height:18px; "><a href="pro_optician_focus.php">Focus</a>, the practice management solution for 
                        independent High Street optical practices </td>
                      <td>&nbsp;</td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                    </tr>
                    <tr>
                      <td valign="top"><a href="pro_optical_labs.php"><img src="images/p3.jpg" width="80" height="80" border="0" /></a></td>
                      <td valign="top" class="text" style="line-height:18px; "><a href="pro_optical_labs.php">DRS Labman</a>, the leading<br /> 
                        complete Lab management software<br /> 
                        in the UK and Europe</td>
                      <td valign="top"><a href="pro_optical_labs_innovations.htm"><img src="images/p4.jpg" width="80" height="80" border="0" /></a></td>
                      <td valign="top" class="text" style="line-height:18px; "><a href="pro_optical_labs_innovations.php">Innovations</a>, the lab Software <br />
                        which automates prescription lens<br /> 
                        processing. </td>
                      <td>&nbsp;</td>
                    </tr>
                    <tr>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                      <td>&nbsp;</td>
                    </tr>
                  </table></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
              </table>
            <!-- InstanceEndEditable --></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      
      
      
      
      
      
    </table></td>
  </tr>
  <tr>
    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>
                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>
                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>
                      </tr>
                    </table></td>
                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>
                  </tr>
              </table></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
    </table></td>
  </tr>
</table>

</body>
<!-- InstanceEnd --></html>
