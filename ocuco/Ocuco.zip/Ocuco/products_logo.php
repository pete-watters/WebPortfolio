 <tr>
        <td height="126" valign="top"><!-- InstanceBeginEditable name="header_graphic" --><img src="images/header_acuitas_optical.jpg" width="932" height="126" border="0" align="top" usemap="#Map" />
            <map name="Map" id="Map">
              <area shape="rect" coords="20,7,135,120" href="index.php" />
              <area shape="circle" coords="678,41,28" href="pro_optician_focus.php" />
              <area shape="circle" coords="775,63,44" href="pro_optician_acuitas_optical.php" />
              <area shape="circle" coords="903,30,19" href="pro_optician_enterprise.php" />
              <area shape="circle" coords="854,60,25" href="pro_optical_labs.php" />
            </map>
        <!-- InstanceEndEditable --></td>
      </tr>