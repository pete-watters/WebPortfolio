<tr>        

<td height="24"></td>      </tr>      
<tr>        
<td><table width="932" border="0" cellspacing="0" cellpadding="0">          
<tr>            <td width="2">&nbsp;</td>            
<td width="215" valign="top">
<table width="100%" border="0" cellspacing="0" cellpadding="0">              
<tr>                
<td width="16" height="35" valign="top">
<img src="images/left_tab_top_left_cnr.jpg" width="16" height="35" /></td>                

<td height="35" background="images/left_tab_bg.jpg" >
<img src="images/products_for_img.jpg" width="70" height="10" /></td>                

<td width="14" height="35" valign="top">
<img src="images/left_tab_top_rght_cnr.jpg" width="14" height="35" /></td>              </tr>              

<tr valign="top">                
<td colspan="3" background="images/left_tab_horizntal_bg.jpg" class="text">
<table width="100%"  border="0" cellspacing="0" cellpadding="0">                 
 <tr>                    
 <td height="245" valign="top"><div class="arrowlistmenu">                      
 
 <h3 class="menuheader expandable">Opticians</h3>                      
 <ul class="categoryitems">					  
 <li><a href="pro_optician_overview.php">Overview</a></li>                        
 <li><a href="pro_optician_acuitas.php">Acuitas </a></li>                                               
 <li style="padding-bottom:8px; "><a href="pro_optician_focus.php">Focus</a></li>                      
 </ul>                      
 
 <h3 class="menuheader expandable">Optical Labs</h3>                      
 <ul class="categoryitems">					    
 <li><a href="pro_optical_labs_overview.php"> Overview</a></li>                        
 <li><a href="pro_optical_labs.php"> Labman</a></li>                        
 <li><a href="pro_optical_labs_innovations.php"> Innovations</a></li>                        
 </ul>                  
 
 
     <h3 class="menuheader expandable">Ophthalmologists</h3>    
 
  <tr>

                  <td colspan="3" class="left_nav2" ><a href="pro_opthalmologist_overview.php" >Overview</a></td>

                </tr>
 <tr>

                  <td colspan="3" class="left_nav2" ><a href="pro_opthalmologist_acuites_clinical.php" >Acuitas Clinical</a></td>

                </tr>


            
                
                <tr>

                  <td colspan="3" class="left_nav2" ><a href="pro_opthalmologist_acuitas_dr.suite.php" > Acuitas DR Suite</a></td>

                </tr>

                <tr>

                  <td colspan="3" class="left_nav2" ><a href="pro_opthalmologist_acuitas_imaging.php" >Acuitas Imaging </a></td>

                </tr>
  
                  
 </div>
 </td>                  
 </tr>                
 </table>
 </td>              
 </tr>        
       
  <tr>                
 <td width="16" height="14" valign="top">
 <img src="images/acc_tab_bott_lft_cnr.jpg" width="16" height="14" align="top" /></td>                
 <td height="14" valign="top">
 <img src="images/acc_tab_bott_img.jpg" width="185" height="14" align="top" /></td>                
 <td width="14" height="14" valign="top"><img src="images/acc_tab_bott_right_cnr.jpg" width="14" height="14" align="top" /></td>              </tr>              
 <tr valign="top">                
 <td height="4" colspan="3"><img src="images/spacer.gif" width="1" height="4" /></td>                </tr>              
 <tr>                
 <td height="20" colspan="3"><table width="100%" border="0" cellspacing="0" cellpadding="0">                  
 <tr>                    
 <td height="33" valign="top">
 <a href="support.php">
 <img src="images/online_support_bttn.jpg" width="215" height="33" border="0" /></a>
 </td>                  
 </tr>                
 </table>
 </td>                
 </tr>          