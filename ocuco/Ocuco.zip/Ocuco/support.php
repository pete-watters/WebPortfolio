<?php include"header_support.php" ?>



      <tr>
        <td height="24"></td>
      </tr>
      <tr>
        <td><table width="932" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="2">&nbsp;</td>
            <td width="215" valign="top"><!-- InstanceBeginEditable name="navigation" -->
              <table width="100%" border="0" cellspacing="0" cellpadding="0" background="images/left_tab_horizntal_bg.jpg">
                <tr>
                  <td width="16" height="35"><img src="images/left_tab_top_left_cnr.jpg" width="16" height="35" /></td>
                  <td height="35" background="images/left_tab_bg.jpg"><img src="images/support.gif" width="44" height="11" /></td>
                  <td width="14" height="35"><img src="images/left_tab_top_rght_cnr.jpg" width="14" height="35" /></td>
                </tr>
                <!--tr>
                <td width="16" height="11"><img src="images/inner_pg_top_lft_cnr.jpg" width="16" height="11" align="top" /></td>
                <td height="11"><img src="images/inner_pg_tab_top_img.jpg" width="185" height="11" align="top" /></td>
                <td width="14" height="11"><img src="images/inner_pg_top_right_cnr.jpg" width="14" height="11" align="top" /></td>
              </tr-->
                <tr>
                  <td colspan="3" class="left_nav">&nbsp;</td>
                </tr>
                <tr>
                  <td colspan="3" class="left_nav"><a href="support.php" class="topsel">Overview</a></td>
                </tr>
                <tr>
                  <td colspan="3" class="left_nav"><a href="support_contact_spprt.php" >Contact Support</a></td>
                </tr>
              
                <tr>
                  <td colspan="3" background="images/left_tab_horizntal_bg.jpg" class="text">&nbsp;</td>
                </tr>
                
                <tr>
                  <td colspan="3" background="images/left_tab_horizntal_bg.jpg" class="text">&nbsp;</td>
                </tr>
                <tr>
                  <td width="16" height="20"><img src="images/left_tab_bttm_lft_cnr.jpg" width="16" height="20" /></td>
                  <td height="20"><img src="images/left_tab_bott_img.jpg" width="185" height="20" /></td>
                  <td width="14" height="20"><img src="images/left_tab_bttm_rght_cnr.jpg" width="14" height="20" /></td>
                </tr>
              </table>
            <!-- InstanceEndEditable --></td>
            <td width="30">&nbsp;</td>
            <td width="685" valign="top"><!-- InstanceBeginEditable name="content_area" -->
              <table width="685" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td height="21" background="images/line_bg.jpg" ><img src="images/customer_support_title.gif" width="130" height="20" /></td>
                </tr>
                <tr>
                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>
                </tr>
                <tr >
                  <td class="text" style="padding-bottom:35px;">This page is for users already in contact with one of our Support engineers.<br />Please do not click on an Operator button unless requested to do so by the<br />Ocuco Customer Support engineer currently dealing with your query. <br />
<br />
If you are looking to contact Customer Support, the telephone numbers for<br />your area and product are <a href="support_contact_spprt.php" style="text-decoration:none;">here</a></td>
                </tr>
                
                <tr>
                  <td bgcolor="#e4e4e4" class="text2" style="font-size:12px;padding-left:6px;  "><a name="dublin" id="dublin"><strong> Dublin </strong></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://www.ocuco.com/inquiero.exe">Download Session File</a></td>
                </tr>
                <tr>
                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>
                </tr>
                <tr>
                  <td><table width="450" border="0" cellspacing="0" cellpadding="0">
                      <tr>
                        <td width="177" class="text" style="font-weight:bold; padding-left:10px; padding-bottom:12px;">Operator : 1</td>
                        <td width="96" rowspan="12">&nbsp;</td>
                        <td width="177" class="text" style="font-weight:bold; padding-left:10px; padding-bottom:12px;">Operator : 2</td>
                      </tr>
                      <tr>
                        <td height="67" valign="top" style="padding-bottom:39px;"> <script language="JavaScript" src="http://inquiero.ocuco.com/inquiero/web/an/ann4.asp?login=I23EEF5&lang=en&oper=support10&Button=NewLook"></script>
<a href="http://inquiero.ocuco.com"><img src="http://inquiero.ocuco.com/inquiero/images/monitor.gif" border="0"></a></td>
                        <td height="67" valign="top" style="padding-bottom:39px;"><script language="JavaScript" src="http://inquiero.ocuco.com/inquiero/web/an/ann4.asp?login=I23EEF5&lang=en&oper=support11&Button=NewLook"></script>
<a href="http://inquiero.ocuco.com"><img src="http://inquiero.ocuco.com/inquiero/images/monitor.gif" border="0"></a></td>
                      </tr>
                      <tr>
                        <td class="text" style="font-weight:bold; padding-left:10px; padding-bottom:12px;">Operator : 3</td>
                        <td class="text" style="font-weight:bold; padding-left:10px; padding-bottom:12px;">Operator : 4</td>
                      </tr>
                      <tr>
                        <td height="67" valign="top" style="padding-bottom:39px;" ><script language="JavaScript" src="http://inquiero.ocuco.com/inquiero/web/an/ann4.asp?login=I23EEF5&lang=en&oper=support12&Button=NewLook"></script>
<a href="http://inquiero.ocuco.com"><img src="http://inquiero.ocuco.com/inquiero/images/monitor.gif" border="0"></a>
</td>
                        <td height="67" valign="top" style="padding-bottom:39px;"><script language="JavaScript" src="http://inquiero.ocuco.com/inquiero/web/an/ann4.asp?login=I23EEF5&lang=en&oper=support13&Button=NewLook"></script>
<a href="http://inquiero.ocuco.com"><img src="http://inquiero.ocuco.com/inquiero/images/monitor.gif" border="0"></a>
</td>
                      </tr>
                      <tr>
                        <td class="text" style="font-weight:bold; padding-left:10px; padding-bottom:12px;">Operator : 5</td>
                        <td class="text" style="font-weight:bold; padding-left:10px; padding-bottom:12px;">Operator : 6</td>
                      </tr>
                      <tr>
                        <td height="67" valign="top" style="padding-bottom:39px;"><script language="JavaScript" src="http://inquiero.ocuco.com/inquiero/web/an/ann4.asp?login=I23EEF5&lang=en&oper=support14&Button=NewLook"></script>
<a href="http://inquiero.ocuco.com"><img src="http://inquiero.ocuco.com/inquiero/images/monitor.gif" border="0"></a>
</td>
                        <td height="67" valign="top" style="padding-bottom:39px;"><script language="JavaScript" src="http://inquiero.ocuco.com/inquiero/web/an/ann4.asp?login=I23EEF5&lang=en&oper=support15&Button=NewLook"></script>
<a href="http://inquiero.ocuco.com"><img src="http://inquiero.ocuco.com/inquiero/images/monitor.gif" border="0"></a>
</td>
                      </tr>
                      <tr>
                        <td class="text" style="font-weight:bold; padding-left:10px; padding-bottom:12px;">Operator : 7</td>
                        <td class="text" style="font-weight:bold; padding-left:10px; padding-bottom:12px;">Operator : 8</td>
                      </tr>
                      <tr>
                        <td height="67" valign="top" style="padding-bottom:39px;"><script language="JavaScript" src="http://inquiero.ocuco.com/inquiero/web/an/ann4.asp?login=I23EEF5&lang=en&oper=support16&Button=NewLook"></script>
<a href="http://inquiero.ocuco.com"><img src="http://inquiero.ocuco.com/inquiero/images/monitor.gif" border="0"></a>
</td>
                        <td height="67" valign="top" style="padding-bottom:39px;"><script language="JavaScript" src="http://inquiero.ocuco.com/inquiero/web/an/ann4.asp?login=I23EEF5&lang=en&oper=support17&Button=NewLook"></script>
<a href="http://inquiero.ocuco.com"><img src="http://inquiero.ocuco.com/inquiero/images/monitor.gif" border="0"></a>
</td>
                      </tr>
                      <tr>
                        <td class="text" style="font-weight:bold; padding-left:10px; padding-bottom:12px;">Operator : 9</td>
                        <td class="text" style="font-weight:bold; padding-left:10px; padding-bottom:12px;">Operator : 10</td>
                      </tr>
                      <tr>
                        <td height="67" valign="top" style="padding-bottom:39px;"><script language="JavaScript" src="http://inquiero.ocuco.com/inquiero/web/an/ann4.asp?login=I23EEF5&lang=en&oper=support18&Button=NewLook"></script>
<a href="http://inquiero.ocuco.com"><img src="http://inquiero.ocuco.com/inquiero/images/monitor.gif" border="0"></a>
</td>
                        <td height="67" valign="top" style="padding-bottom:39px;"><script language="JavaScript" src="http://inquiero.ocuco.com/inquiero/web/an/ann4.asp?login=I23EEF5&lang=en&oper=support19&Button=NewLook"></script>
<a href="http://inquiero.ocuco.com"><img src="http://inquiero.ocuco.com/inquiero/images/monitor.gif" border="0"></a>
</td>
                      </tr>
                      <tr>
                        <td class="text" style="font-weight:bold; padding-left:10px; padding-bottom:12px;">Operator : 11 </td>
                        <td class="text" style="font-weight:bold; padding-left:10px; padding-bottom:12px;">Operator : 12</td>
                      </tr>
                      <tr>
                        <td height="67" valign="top" style="padding-bottom:39px;"><script language="JavaScript" src="http://inquiero.ocuco.com/inquiero/web/an/ann4.asp?login=I23EEF5&lang=en&oper=support20&Button=NewLook"></script>
<a href="http://inquiero.ocuco.com"><img src="http://inquiero.ocuco.com/inquiero/images/monitor.gif" border="0"></a>
</td>
                        <td height="67" valign="top" style="padding-bottom:39px;"><script language="JavaScript" src="http://inquiero.ocuco.com/inquiero/web/an/ann4.asp?login=I23EEF5&lang=en&oper=support21&Button=NewLook"></script>
<a href="http://inquiero.ocuco.com"><img src="http://inquiero.ocuco.com/inquiero/images/monitor.gif" border="0"></a>
</td>
                      </tr>
                  </table></td>
                </tr>
                <tr>
                  <td height="8"><img src="images/spacer.gif" width="1" height="8" /></td>
                </tr>
                
                  </table></td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
              </table>
            <!-- InstanceEndEditable --></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      
      
      
      
      
      
    </table></td>
  </tr>
  <tr>
    <td height="38" class="footer_bg"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="38" class="footer_bg"><table width="932" border="0" align="center" cellpadding="0" cellspacing="0">
            <tr>
              <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td width="13" height="38" align="left" valign="top"><img src="images/footer_left_cnr.jpg" width="13" height="38" /></td>
                    <td width="906" background="images/footer_tab_bg.jpg" valign="middle"><table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                      <tr>
                        <td width="524" height="38" valign="middle" class="footer_text">Phone : UK - 0800 9121004 , Ireland - 1800 927191.</td>
                        <td width="382" valign="middle" class="footer_right_text" >Designed by <a href="http://www.fractalink.com" target="_blank">fractal | ink</a></td>
                      </tr>
                    </table></td>
                    <td width="13"><img src="images/footer_right_cnr.jpg" width="13" height="38" /></td>
                  </tr>
              </table></td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
      
    </table></td>
  </tr>
</table>

</body>
<!-- InstanceEnd --></html>
