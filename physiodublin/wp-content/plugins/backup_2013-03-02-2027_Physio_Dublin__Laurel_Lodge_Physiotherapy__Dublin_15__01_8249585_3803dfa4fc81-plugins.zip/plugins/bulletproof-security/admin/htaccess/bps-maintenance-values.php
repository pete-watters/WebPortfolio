<?php
$bps_retry_after = '';
$bps_site_title = '';
$bps_message1 = '';
$bps_message2 = '';
$bps_body_background_image = '';
?>