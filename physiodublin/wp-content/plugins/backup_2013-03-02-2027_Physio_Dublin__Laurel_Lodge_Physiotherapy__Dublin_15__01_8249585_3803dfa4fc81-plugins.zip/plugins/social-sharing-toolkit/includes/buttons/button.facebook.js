jQuery(document).ready( function($) {
	$('body').prepend('<div id="fb-root"></div>');	
});