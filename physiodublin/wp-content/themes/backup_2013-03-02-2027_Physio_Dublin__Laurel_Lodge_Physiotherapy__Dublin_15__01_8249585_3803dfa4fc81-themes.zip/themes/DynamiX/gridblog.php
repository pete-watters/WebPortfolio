<?php
/**
 * @package WordPress
 * @subpackage Default_Theme
*/

/*
Template Name: Grid Blog
*/ 

$forceDYN_gridblog="grid";

require "blog.php"; // get blog template ?>