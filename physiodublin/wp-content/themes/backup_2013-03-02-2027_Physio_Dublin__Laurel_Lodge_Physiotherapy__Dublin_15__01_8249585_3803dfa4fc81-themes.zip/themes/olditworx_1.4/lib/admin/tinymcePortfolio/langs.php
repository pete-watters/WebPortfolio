<?php
$strings = "tinyMCE.addI18n({en:{
phi_portfolio:{
desc : 'Add Portfolio'
},
phi_shortcode:{
desc : 'Add Custom Shortcode'
},
phi_contact:{
desc : 'Add Contact Form'
}}});
";

?>