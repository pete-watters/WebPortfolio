<?php
		// SOCIABLES - PULLED FROM THEME ADMIN
		
		$smi_image_1=get_option('phi_smi_image_1');
		$smi_url_1=get_option('phi_smi_url_1');
		$smi_text_1=get_option('phi_smi_text_1');

		$smi_image_2=get_option('phi_smi_image_2');
		$smi_url_2=get_option('phi_smi_url_2');
		$smi_text_2=get_option('phi_smi_text_2');

		$smi_image_3=get_option('phi_smi_image_3');
		$smi_url_3=get_option('phi_smi_url_3');
		$smi_text_3=get_option('phi_smi_text_3');
		
		$smi_image_4=get_option('phi_smi_image_4');
		$smi_url_4=get_option('phi_smi_url_4');
		$smi_text_4=get_option('phi_smi_text_4');
		
		$smi_image_5=get_option('phi_smi_image_5');
		$smi_url_5=get_option('phi_smi_url_5');
		$smi_text_5=get_option('phi_smi_text_5');
		
		$smi_image_6=get_option('phi_smi_image_6');
		$smi_url_6=get_option('phi_smi_url_6');
		$smi_text_6=get_option('phi_smi_text_6');
		
		$smi_image_7=get_option('phi_smi_image_7');
		$smi_url_7=get_option('phi_smi_url_7');
		$smi_text_7=get_option('phi_smi_text_7');
		
		$smi_image_8=get_option('phi_smi_image_8');
		$smi_url_8=get_option('phi_smi_url_8');
		$smi_text_8=get_option('phi_smi_text_8');
		
		$smi_image_9=get_option('phi_smi_image_9');
		$smi_url_9=get_option('phi_smi_url_9');
		$smi_text_9=get_option('phi_smi_text_9');
		
		$smi_image_10=get_option('phi_smi_image_10');
		$smi_url_10=get_option('phi_smi_url_10');
		$smi_text_10=get_option('phi_smi_text_10');
		
		?>

				<ul class="social">
			<?php if ($smi_image_1==true and $smi_url_1==true):?>
			<li><a href="<?php echo $smi_url_1;?>" title="<?php echo $smi_text_1;?>" rel="external"><img src="<?php echo $smi_image_1;?>" class="clearborder" alt="<?php echo $smi_text_1;?>" /></a></li>
			<?php endif;?>
			<?php if ($smi_image_2==true and $smi_url_2==true):?>
			<li><a href="<?php echo $smi_url_2;?>" title="<?php echo $smi_text_2;?>" rel="external"><img src="<?php echo $smi_image_2;?>" class="clearborder" alt="<?php echo $smi_text_2;?>" /></a></li>
			<?php endif;?>
			<?php if ($smi_image_3==true and $smi_url_3==true):?>
			<li><a href="<?php echo $smi_url_3;?>" title="<?php echo $smi_text_3;?>" rel="external"><img src="<?php echo $smi_image_3;?>" class="clearborder" alt="<?php echo $smi_text_3;?>" /></a></li>
			<?php endif;?>
			<?php if ($smi_image_4==true and $smi_url_4==true):?>
			<li><a href="<?php echo $smi_url_4;?>" title="<?php echo $smi_text_4;?>" rel="external"><img src="<?php echo $smi_image_4;?>" class="clearborder" alt="<?php echo $smi_text_4;?>" /></a></li>
			<?php endif;?>
			<?php if ($smi_image_5==true and $smi_url_5==true):?>
			<li><a href="<?php echo $smi_url_5;?>" title="<?php echo $smi_text_5;?>" rel="external"><img src="<?php echo $smi_image_5;?>" class="clearborder" alt="<?php echo $smi_text_5;?>" /></a></li>
			<?php endif;?>
			<?php if ($smi_image_6==true and $smi_url_6==true):?>
			<li><a href="<?php echo $smi_url_6;?>" title="<?php echo $smi_text_6;?>" rel="external"><img src="<?php echo $smi_image_6;?>" class="clearborder" alt="<?php echo $smi_text_6;?>" /></a></li>
			<?php endif;?>
			<?php if ($smi_image_7==true and $smi_url_7==true):?>
			<li><a href="<?php echo $smi_url_7;?>" title="<?php echo $smi_text_7;?>" rel="external"><img src="<?php echo $smi_image_7;?>" class="clearborder" alt="<?php echo $smi_text_7;?>" /></a></li>
			<?php endif;?>
			<?php if ($smi_image_8==true and $smi_url_8==true):?>
			<li><a href="<?php echo $smi_url_8;?>" title="<?php echo $smi_text_8;?>" rel="external"><img src="<?php echo $smi_image_8;?>" class="clearborder" alt="<?php echo $smi_text_8;?>" /></a></li>
			<?php endif;?>
			<?php if ($smi_image_9==true and $smi_url_9==true):?>
			<li><a href="<?php echo $smi_url_9;?>" title="<?php echo $smi_text_9;?>" rel="external"><img src="<?php echo $smi_image_9;?>" class="clearborder" alt="<?php echo $smi_text_9;?>" /></a></li>
			<?php endif;?>
			<?php if ($smi_image_10==true and $smi_url_10==true):?>
			<li><a href="<?php echo $smi_url_10;?>" title="<?php echo $smi_text_10;?>" rel="external"><img src="<?php echo $smi_image_10;?>" class="clearborder" alt="<?php echo $smi_text_10;?>" /></a></li>
			<?php endif;?>
				</ul>
