/******************************************************************************** 	
	Spiderscript Javascript Library Readme						
	v1.0.8.20090930									
	Copyright (C) 2008 - 2009 Allen Evans						
	http://www.spiderscript.net/							
********************************************************************************/ 	
 											
File Index									 	
---------------------------------------------------------			 	
License.txt									
	Spiderscript LGPL License							
	JSON Source Public Domain License						
 											
spiderscript_base_v1.0.8.20090930.js 							
	Basic Spiderscript library without any controls.				
	Compacted using JSMIN.								
	Use if not using any Spirderscript controls such as the calendar or window.	
 											
spiderscript_base_v1.0.8.20090930.js 							
	Basic Spiderscript library without any controls.				
	Compacted using YUI Compressor 2.4.2.						
	Use if not using any Spirderscript controls such as the calendar or window.	
 											
spiderscript_complete_v1.0.8.20090930.css						
	CSS style sheet for defining styles used in Spiderscript Controls.		
 											
spiderscript_complete_v1.0.8.20090930_yui.css						
	CSS style sheet for defining styles used in Spiderscript Controls.		
	Compacted using YUI Compressor 2.4.2.						
		 									
spiderscript_complete_v1.0.8.20090930.js						
Complete Spiderscript Javascript Library. 					
	Compacted using JSMIN.								
		 									
spiderscript_complete_v1.0.8.20090930_yui.js					
Complete Spiderscript Javascript Library. 					
	Compacted using YUI Compressor 2.4.2.						
		 									
spiderscript_source_v1.0.8.20090930_SS.js						
Complete Spiderscript Javascript Library. 					
 											
source/JSON.js										
		 									
source/spiderscript_source_v1.0.8.20090930_SS.control.calendar.js				
		 									
source/spiderscript_source_v1.0.8.20090930_SS.control.dropzone.js				
		 									
source/spiderscript_source_v1.0.8.20090930_SS.control.imagetoggle.js			
		 									
source/spiderscript_source_v1.0.8.20090930_SS.control.js					
		 									
source/spiderscript_source_v1.0.8.20090930_SS.control.logo.js				
		 									
source/spiderscript_source_v1.0.8.20090930_SS.control.menu.js				
 											
source/spiderscript_source_v1.0.8.20090930_SS.control.menuitem.js				
 											
source/spiderscript_source_v1.0.8.20090930_SS.control.moveable.js				
 											
source/spiderscript_source_v1.0.8.20090930_SS.control.passwordmeter.js			
		 									
source/spiderscript_source_v1.0.8.20090930_SS.control.popup.js 				
		 									
source/spiderscript_source_v1.0.8.20090930_SS.control.popupcalendar.js			
		 									
source/spiderscript_source_v1.0.8.20090930_SS.control.richtextbox.js			
		 									
source/spiderscript_source_v1.0.8.20090930_SS.control.searchbox.js			
		 									
source/spiderscript_source_v1.0.8.20090930_SS.control.slider.js				
		 									
source/spiderscript_source_v1.0.8.20090930_SS.control.tab.js				
		 									
source/spiderscript_source_v1.0.8.20090930_SS.control.tabbar.js				
		 									
source/spiderscript_source_v1.0.8.20090930_SS.control.tree.js				
		 									
source/spiderscript_source_v1.0.8.20090930_SS.control.window.js				
		 									
source/spiderscript_source_v1.0.8.20090930_SS.core.js					
		 									
source/spiderscript_source_v1.0.8.20090930_SS.datetime.js				
		 									
source/spiderscript_source_v1.0.8.20090930_SS.geom.js					
		 									
source/spiderscript_source_v1.0.8.20090930_SS.global.js					
		 									
source/spiderscript_source_v1.0.8.20090930_SS.htmlextension.js				
		 									
source/spiderscript_source_v1.0.8.20090930_SS.init.js					
		 									
source/spiderscript_source_v1.0.8.20090930_SS.locale.js					
		 									
source/spiderscript_source_v1.0.8.20090930_SS.net.js					
		 									
source/spiderscript_source_v1.0.8.20090930_SS.util.js					
		 									
