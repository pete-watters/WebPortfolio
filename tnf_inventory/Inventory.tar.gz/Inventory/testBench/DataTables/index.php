<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		
        <title>DataTables example</title>
		
	</head>
	<body>
        			
<iframe src="table.html" width="100%" height="100%" name="Main" id="frame_id" vspace="0" hspace="0" marginwidth="0" marginheight="0" scrolling="no" noresize></iframe>

	</body>
</html>